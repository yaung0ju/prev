"use client"

import { useState, useEffect } from "react"

interface Product {
  id: number
  name: string
  brand: string
  price: number
  originalPrice?: number
  image: string
  isLiked?: boolean
  category: string
  viewCount?: number
  likeCount?: number
}

interface RecommendationData {
  itemForYou: Product[]
  recentlyViewed: Product[]
  popular: Product[]
  loading: boolean
  error: string | null
}

// Mock data - 실제로는 Supabase에서 가져올 데이터
const mockProducts: Product[] = [
  {
    id: 1,
    name: "클래식 토트백",
    brand: "CHANEL",
    price: 4500000,
    originalPrice: 5000000,
    image: "/placeholder.svg?height=300&width=300",
    isLiked: false,
    category: "가방",
    viewCount: 1250,
    likeCount: 89,
  },
  {
    id: 2,
    name: "골드 체인 목걸이",
    brand: "TIFFANY & CO.",
    price: 1200000,
    image: "/placeholder.svg?height=300&width=300",
    isLiked: true,
    category: "주얼리",
    viewCount: 980,
    likeCount: 156,
  },
  {
    id: 3,
    name: "레더 크로스백",
    brand: "LOUIS VUITTON",
    price: 3200000,
    image: "/placeholder.svg?height=300&width=300",
    isLiked: false,
    category: "가방",
    viewCount: 2100,
    likeCount: 203,
  },
  {
    id: 4,
    name: "실버 브레이슬릿",
    brand: "CARTIER",
    price: 2800000,
    originalPrice: 3200000,
    image: "/placeholder.svg?height=300&width=300",
    isLiked: false,
    category: "주얼리",
    viewCount: 756,
    likeCount: 67,
  },
  {
    id: 5,
    name: "미니 숄더백",
    brand: "HERMÈS",
    price: 6500000,
    image: "/placeholder.svg?height=300&width=300",
    isLiked: true,
    category: "가방",
    viewCount: 3200,
    likeCount: 445,
  },
  {
    id: 6,
    name: "다이아몬드 반지",
    brand: "TIFFANY & CO.",
    price: 8900000,
    image: "/placeholder.svg?height=300&width=300",
    isLiked: false,
    category: "주얼리",
    viewCount: 1890,
    likeCount: 234,
  },
  {
    id: 7,
    name: "클러치백",
    brand: "BOTTEGA VENETA",
    price: 2100000,
    image: "/placeholder.svg?height=300&width=300",
    isLiked: true,
    category: "가방",
    viewCount: 1456,
    likeCount: 178,
  },
  {
    id: 8,
    name: "진주 귀걸이",
    brand: "CHANEL",
    price: 1800000,
    image: "/placeholder.svg?height=300&width=300",
    isLiked: false,
    category: "주얼리",
    viewCount: 892,
    likeCount: 123,
  },
  {
    id: 9,
    name: "백팩",
    brand: "PRADA",
    price: 2900000,
    image: "/placeholder.svg?height=300&width=300",
    isLiked: false,
    category: "가방",
    viewCount: 1234,
    likeCount: 89,
  },
]

export function useSupabaseRecommendations(): RecommendationData {
  const [data, setData] = useState<RecommendationData>({
    itemForYou: [],
    recentlyViewed: [],
    popular: [],
    loading: true,
    error: null,
  })

  useEffect(() => {
    // Simulate API call
    const fetchRecommendations = async () => {
      try {
        // Simulate loading delay
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Mock logic for different recommendation types
        const userLikedCategories = ["가방", "주얼리"] // 사용자가 좋아요한 카테고리

        const itemForYou = mockProducts.filter((product) => userLikedCategories.includes(product.category)).slice(0, 9)

        const recentlyViewed = mockProducts
          .sort((a, b) => Math.random() - 0.5) // Random for demo
          .slice(0, 9)

        const popular = mockProducts.sort((a, b) => (b.viewCount || 0) - (a.viewCount || 0)).slice(0, 9)

        setData({
          itemForYou,
          recentlyViewed,
          popular,
          loading: false,
          error: null,
        })
      } catch (error) {
        setData((prev) => ({
          ...prev,
          loading: false,
          error: "데이터를 불러오는데 실패했습니다.",
        }))
      }
    }

    fetchRecommendations()
  }, [])

  return data
}
