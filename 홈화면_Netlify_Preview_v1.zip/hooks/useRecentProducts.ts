"use client"

import { useState, useEffect } from "react"

interface RecentProduct {
  id: number
  name: string
  brand: string
  price: number
  originalPrice?: number
  image: string
  viewedAt: number
}

export function useRecentProducts() {
  const [recentProducts, setRecentProducts] = useState<RecentProduct[]>([])

  useEffect(() => {
    // Load from localStorage
    const stored = localStorage.getItem("recentProducts")
    if (stored) {
      try {
        const products = JSON.parse(stored)
        setRecentProducts(products)
      } catch (error) {
        console.error("Failed to parse recent products:", error)
      }
    }
  }, [])

  const addRecentProduct = (product: Omit<RecentProduct, "viewedAt">) => {
    const newProduct = { ...product, viewedAt: Date.now() }

    setRecentProducts((prev) => {
      // Remove if already exists
      const filtered = prev.filter((p) => p.id !== product.id)
      // Add to beginning
      const updated = [newProduct, ...filtered].slice(0, 20) // Keep only 20 recent items

      // Save to localStorage
      localStorage.setItem("recentProducts", JSON.stringify(updated))

      return updated
    })
  }

  const removeRecentProduct = (productId: number) => {
    setRecentProducts((prev) => {
      const updated = prev.filter((p) => p.id !== productId)
      localStorage.setItem("recentProducts", JSON.stringify(updated))
      return updated
    })
  }

  const clearRecentProducts = () => {
    setRecentProducts([])
    localStorage.removeItem("recentProducts")
  }

  return { recentProducts, addRecentProduct, removeRecentProduct, clearRecentProducts }
}
