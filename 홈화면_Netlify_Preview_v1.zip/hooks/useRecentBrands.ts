"use client"

import { useState, useEffect } from "react"

interface Brand {
  id: number
  name: string
  nameEN: string
  image: string
  category: string
  viewedAt: number
}

export function useRecentBrands() {
  const [recentBrands, setRecentBrands] = useState<Brand[]>([])

  useEffect(() => {
    // Load from localStorage
    const stored = localStorage.getItem("recentBrands")
    if (stored) {
      try {
        const brands = JSON.parse(stored)
        setRecentBrands(brands)
      } catch (error) {
        console.error("Failed to parse recent brands:", error)
      }
    }
  }, [])

  const addRecentBrand = (brand: Omit<Brand, "viewedAt">) => {
    const newBrand = { ...brand, viewedAt: Date.now() }

    setRecentBrands((prev) => {
      // Remove if already exists
      const filtered = prev.filter((b) => b.id !== brand.id)
      // Add to beginning
      const updated = [newBrand, ...filtered].slice(0, 10) // Keep only 10 recent items

      // Save to localStorage
      localStorage.setItem("recentBrands", JSON.stringify(updated))

      return updated
    })
  }

  const clearRecentBrands = () => {
    setRecentBrands([])
    localStorage.removeItem("recentBrands")
  }

  return { recentBrands, addRecentBrand, clearRecentBrands }
}
