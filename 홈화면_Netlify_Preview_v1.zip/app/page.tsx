"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import Header from "@/components/header"
import CategorySidebar from "@/components/category-sidebar"
import BannerSlider from "@/components/banner-slider"
import ProcessSection from "@/components/process-section"
import RankingAndRecommendationSection from "@/components/ranking-and-recommendation-section"
import BoutiqueBestBrandsSection from "@/components/boutique-best-brands-section"
import FixedBrandSliderSection, { mockBrandDataAPC, mockBrandDataFits } from "@/components/fixed-brand-slider-section"
import RecommendedCategoriesSection from "@/components/recommended-categories-section"
import RecommendationSections from "@/components/recommendation-sections"
import FloatingNav from "@/components/floating-nav"
import BottomNav from "@/components/bottom-nav"
import Footer from "@/components/footer"
import SearchModal from "@/components/search-modal"

export default function HomePage() {
  const [isCategorySidebarOpen, setIsCategorySidebarOpen] = useState(false)
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false)
  const [activeBottomNav, setActiveBottomNav] = useState("홈")
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true)
      } else {
        setIsScrolled(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => {
      window.removeEventListener("scroll", handleScroll)
    }
  }, [])

  // Modify the imported mock data directly
  mockBrandDataAPC.sectionTitle = "시즌제 광고배너"
  mockBrandDataFits.sectionTitle = ""

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header onSearchClick={() => setIsSearchModalOpen(true)} onCategoryClick={() => {}} />

      <main className="flex-1 pb-20">
        {/* Full-width Banner */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.8 }}>
          <BannerSlider />
        </motion.div>

        {/* Process Section */}
        <ProcessSection />

        {/* NEW ARRIVAL Section (실시간 랭킹) */}
        <RankingAndRecommendationSection />

        {/* Popular Products Section (부티크 베스트 브랜드) */}
        <BoutiqueBestBrandsSection />

        {/* New Fixed Brand Slider Section (트렌드 브랜드 지갑) */}
        <FixedBrandSliderSection {...mockBrandDataAPC} />

        {/* New Fixed Brand Slider Section (시즌제 광고배너) */}
        <FixedBrandSliderSection {...mockBrandDataFits} />

        {/* Recommended Categories Section */}
        <RecommendedCategoriesSection />

        {/* Recommendation Sections */}
        <div className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 md:px:8">
            <RecommendationSections />
          </div>
        </div>
      </main>

      <CategorySidebar isOpen={isCategorySidebarOpen} onClose={() => setIsCategorySidebarOpen(false)} />

      <SearchModal isOpen={isSearchModalOpen} onClose={() => setIsSearchModalOpen(false)} />

      <FloatingNav />

      <BottomNav
        activeMenu={activeBottomNav}
        onMenuClick={setActiveBottomNav}
        onCategoryClick={() => setIsCategorySidebarOpen(true)}
      />

      <Footer />
    </div>
  )
}
