"use client"

import type React from "react"

import { useState, useEffect, useRef, useCallback } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Search, ArrowLeft, Clock, TrendingUp, Star, List } from "lucide-react"
import Image from "next/image"
import { useRouter, useSearchParams } from "next/navigation"
import { useDebounce } from "@/hooks/useDebounce"
import { useRecentBrands } from "@/hooks/useRecentBrands"
import { SearchSkeleton, TabContentSkeleton } from "@/components/skeleton-ui"
import { EmptyState } from "@/components/empty-state"
import { FullScreenLoader } from "@/components/loading-spinner"
import BrandCategoryList from "@/components/brand-category-list"

interface Brand {
  id: number
  name: string
  nameEN: string
  image: string
  category: string
  viewedAt?: number
}

const recommendedBrands: Brand[] = [
  {
    id: 1,
    name: "샤넬",
    nameEN: "CHANEL",
    image: "/placeholder.svg?height=48&width=48",
    category: "럭셔리",
  },
  {
    id: 2,
    name: "루이비통",
    nameEN: "LOUIS VUITTON",
    image: "/placeholder.svg?height=48&width=48",
    category: "가방",
  },
  {
    id: 3,
    name: "에르메스",
    nameEN: "HERMÈS",
    image: "/placeholder.svg?height=48&width=48",
    category: "럭셔리",
  },
  {
    id: 4,
    name: "구찌",
    nameEN: "GUCCI",
    image: "/placeholder.svg?height=48&width=48",
    category: "패션",
  },
  {
    id: 5,
    name: "프라다",
    nameEN: "PRADA",
    image: "/placeholder.svg?height=48&width=48",
    category: "가방",
  },
  {
    id: 6,
    name: "디올",
    nameEN: "DIOR",
    image: "/placeholder.svg?height=48&width=48",
    category: "뷰티",
  },
  {
    id: 7,
    name: "보테가베네타",
    nameEN: "BOTTEGA VENETA",
    image: "/placeholder.svg?height=48&width=48",
    category: "가방",
  },
  {
    id: 8,
    name: "생로랑",
    nameEN: "SAINT LAURENT",
    image: "/placeholder.svg?height=48&width=48",
    category: "패션",
  },
  {
    id: 9,
    name: "발렌시아가",
    nameEN: "BALENCIAGA",
    image: "/placeholder.svg?height=48&width=48",
    category: "스니커즈",
  },
  {
    id: 10,
    name: "셀린느",
    nameEN: "CELINE",
    image: "/placeholder.svg?height=48&width=48",
    category: "가방",
  },
  {
    id: 11,
    name: "까르띠에",
    nameEN: "CARTIER",
    image: "/placeholder.svg?height=48&width=48",
    category: "주얼리",
  },
  {
    id: 12,
    name: "티파니",
    nameEN: "TIFFANY & CO.",
    image: "/placeholder.svg?height=48&width=48",
    category: "주얼리",
  },
  {
    id: 13,
    name: "롤렉스",
    nameEN: "ROLEX",
    image: "/placeholder.svg?height=48&width=48",
    category: "시계",
  },
  {
    id: 14,
    name: "오메가",
    nameEN: "OMEGA",
    image: "/placeholder.svg?height=48&width=48",
    category: "시계",
  },
]

const recommendedKeywords = ["가방", "주얼리", "시계", "패션", "뷰티", "스니커즈", "럭셔리", "한정판", "신상품", "할인"]

const popularBrands = recommendedBrands.slice(0, 8)

type TabType = "keywords" | "popular" | "recent" | "categories"

export default function SearchPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [filteredBrands, setFilteredBrands] = useState(recommendedBrands)
  const [isLoading, setIsLoading] = useState(false)
  const [isNavigating, setIsNavigating] = useState(false)
  const [selectedIndex, setSelectedIndex] = useState(-1)
  const [activeTab, setActiveTab] = useState<TabType>("keywords")
  const [tabLoading, setTabLoading] = useState(false)
  const [loadingKeyword, setLoadingKeyword] = useState<string | null>(null)
  const [loadingBrandId, setLoadingBrandId] = useState<number | null>(null)
  const router = useRouter()
  const searchParams = useSearchParams()
  const inputRef = useRef<HTMLInputElement>(null)
  const brandRefs = useRef<(HTMLButtonElement | null)[]>([])
  const keywordRefs = useRef<(HTMLButtonElement | null)[]>([])
  const { recentBrands, addRecentBrand, clearRecentBrands } = useRecentBrands()

  // Debounced search query
  const debouncedSearchQuery = useDebounce(searchQuery, 300)

  // Initialize search from URL params
  useEffect(() => {
    const q = searchParams.get("q")
    if (q) {
      setSearchQuery(q)
    }
  }, [searchParams])

  // Perform search with debounced query
  useEffect(() => {
    const performSearch = async () => {
      setIsLoading(true)
      setSelectedIndex(-1)

      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 300))

      if (debouncedSearchQuery.trim() === "") {
        setFilteredBrands(recommendedBrands)
      } else {
        const filtered = recommendedBrands.filter(
          (brand) =>
            brand.name.toLowerCase().includes(debouncedSearchQuery.toLowerCase()) ||
            brand.nameEN.toLowerCase().includes(debouncedSearchQuery.toLowerCase()) ||
            brand.category.toLowerCase().includes(debouncedSearchQuery.toLowerCase()),
        )
        setFilteredBrands(filtered)
      }

      setIsLoading(false)
    }

    performSearch()
  }, [debouncedSearchQuery])

  // Handle tab loading
  useEffect(() => {
    const loadTabContent = async () => {
      setTabLoading(true)
      setSelectedIndex(-1)

      // Simulate loading delay for tab content
      await new Promise((resolve) => setTimeout(resolve, 200))

      setTabLoading(false)
    }

    if (!searchQuery) {
      loadTabContent()
    }
  }, [activeTab, searchQuery])

  // Update refs arrays
  useEffect(() => {
    brandRefs.current = brandRefs.current.slice(0, filteredBrands.length)
  }, [filteredBrands.length])

  useEffect(() => {
    if (activeTab === "keywords") {
      keywordRefs.current = keywordRefs.current.slice(0, recommendedKeywords.length)
    } else if (activeTab === "popular") {
      brandRefs.current = brandRefs.current.slice(0, popularBrands.length)
    } else if (activeTab === "recent") {
      brandRefs.current = brandRefs.current.slice(0, recentBrands.length)
    }
  }, [activeTab, recentBrands.length])

  const handleBrandClick = useCallback(
    async (brand: Brand) => {
      setLoadingBrandId(brand.id)
      setIsNavigating(true)

      // Add to recent brands
      addRecentBrand(brand)

      // Simulate navigation delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      console.log(`Navigate to ${brand.name} page`)
      // router.push(`/brand/${brand.id}`)

      setLoadingBrandId(null)
      setIsNavigating(false)
    },
    [addRecentBrand],
  )

  const handleKeywordClick = async (keyword: string) => {
    setLoadingKeyword(keyword)

    // Simulate loading delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    setSearchQuery(keyword)
    inputRef.current?.focus()
    setLoadingKeyword(null)
  }

  const handleBack = () => {
    router.back()
  }

  const getCurrentItems = () => {
    if (searchQuery) {
      return filteredBrands
    }

    switch (activeTab) {
      case "keywords":
        return recommendedKeywords
      case "popular":
        return popularBrands
      case "recent":
        return recentBrands
      case "categories":
        return []
      default:
        return []
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    const currentItems = getCurrentItems()
    if (currentItems.length === 0 || activeTab === "categories") return

    switch (e.key) {
      case "ArrowDown":
        e.preventDefault()
        setSelectedIndex((prev) => {
          const next = prev < currentItems.length - 1 ? prev + 1 : 0
          setTimeout(() => {
            if (searchQuery || activeTab !== "keywords") {
              brandRefs.current[next]?.scrollIntoView({
                behavior: "smooth",
                block: "nearest",
              })
            } else {
              keywordRefs.current[next]?.scrollIntoView({
                behavior: "smooth",
                block: "nearest",
              })
            }
          }, 0)
          return next
        })
        break

      case "ArrowUp":
        e.preventDefault()
        setSelectedIndex((prev) => {
          const next = prev > 0 ? prev - 1 : currentItems.length - 1
          setTimeout(() => {
            if (searchQuery || activeTab !== "keywords") {
              brandRefs.current[next]?.scrollIntoView({
                behavior: "smooth",
                block: "nearest",
              })
            } else {
              keywordRefs.current[next]?.scrollIntoView({
                behavior: "smooth",
                block: "nearest",
              })
            }
          }, 0)
          return next
        })
        break

      case "Enter":
        e.preventDefault()
        if (selectedIndex >= 0 && selectedIndex < currentItems.length) {
          const item = currentItems[selectedIndex]
          if (searchQuery || activeTab !== "keywords") {
            // Brand item
            handleBrandClick(item as Brand)
          } else {
            // Keyword item
            handleKeywordClick(item as string)
          }
        }
        break

      case "Escape":
        setSelectedIndex(-1)
        inputRef.current?.blur()
        break
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value)
    setSelectedIndex(-1)
  }

  const handleClearSearch = () => {
    setSearchQuery("")
    setSelectedIndex(-1)
    inputRef.current?.focus()
  }

  const getTabContent = () => {
    if (tabLoading && activeTab !== "categories") {
      return <TabContentSkeleton type={activeTab === "keywords" ? "keywords" : "brands"} />
    }

    switch (activeTab) {
      case "keywords":
        return (
          <div className="flex flex-wrap gap-2">
            {recommendedKeywords.map((keyword, index) => (
              <motion.button
                key={keyword}
                ref={(el) => {
                  keywordRefs.current[index] = el
                }}
                className={`min-h-12 px-4 py-2 rounded-full text-sm transition-colors outline-none flex items-center justify-center ${
                  selectedIndex === index
                    ? "bg-pink-100 text-pink-600 ring-2 ring-pink-200"
                    : "bg-gray-100 hover:bg-pink-100 hover:text-pink-600"
                }`}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.2, delay: index * 0.05 }}
                onClick={() => handleKeywordClick(keyword)}
                onMouseEnter={() => setSelectedIndex(index)}
                onMouseLeave={() => setSelectedIndex(-1)}
                disabled={loadingKeyword === keyword}
              >
                {loadingKeyword === keyword ? (
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 border-2 border-pink-300 border-t-pink-500 rounded-full animate-spin"></div>
                    <span>{keyword}</span>
                  </div>
                ) : (
                  keyword
                )}
              </motion.button>
            ))}
          </div>
        )

      case "popular":
        return (
          <div className="grid grid-cols-2 gap-4">
            {popularBrands.map((brand, index) => (
              <motion.button
                key={brand.id}
                ref={(el) => {
                  brandRefs.current[index] = el
                }}
                className={`min-h-12 p-4 bg-white border rounded-lg shadow hover:shadow-md transition-all duration-200 text-left outline-none ${
                  selectedIndex === index
                    ? "border-pink-500 bg-pink-50 ring-2 ring-pink-200"
                    : "border-gray-200 hover:border-pink-300"
                }`}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
                whileHover={{ scale: selectedIndex === index ? 1 : 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => handleBrandClick(brand)}
                onMouseEnter={() => setSelectedIndex(index)}
                onMouseLeave={() => setSelectedIndex(-1)}
                disabled={loadingBrandId === brand.id}
              >
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src={brand.image || "/placeholder.svg"}
                      alt={brand.name}
                      width={48}
                      height={48}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">{brand.name}</p>
                    <p className="text-xs text-gray-500 truncate">{brand.nameEN}</p>
                    <p className="text-xs text-pink-500 mt-1">{brand.category}</p>
                  </div>
                  {loadingBrandId === brand.id && (
                    <div className="w-4 h-4 border-2 border-pink-300 border-t-pink-500 rounded-full animate-spin flex-shrink-0"></div>
                  )}
                </div>
              </motion.button>
            ))}
          </div>
        )

      case "recent":
        if (recentBrands.length === 0) {
          return <EmptyState type="recent" onAction={() => setActiveTab("popular")} actionLabel="인기 브랜드 보기" />
        }

        return (
          <div>
            <div className="flex justify-between items-center mb-4">
              <p className="text-sm text-gray-500">{recentBrands.length}개의 최근 본 브랜드</p>
              <button onClick={clearRecentBrands} className="text-xs text-gray-400 hover:text-gray-600">
                전체 삭제
              </button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {recentBrands.map((brand, index) => (
                <motion.button
                  key={`${brand.id}-${brand.viewedAt}`}
                  ref={(el) => {
                    brandRefs.current[index] = el
                  }}
                  className={`min-h-12 p-4 bg-white border rounded-lg shadow hover:shadow-md transition-all duration-200 text-left outline-none ${
                    selectedIndex === index
                      ? "border-pink-500 bg-pink-50 ring-2 ring-pink-200"
                      : "border-gray-200 hover:border-pink-300"
                  }`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.05 }}
                  whileHover={{ scale: selectedIndex === index ? 1 : 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleBrandClick(brand)}
                  onMouseEnter={() => setSelectedIndex(index)}
                  onMouseLeave={() => setSelectedIndex(-1)}
                  disabled={loadingBrandId === brand.id}
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                      <Image
                        src={brand.image || "/placeholder.svg"}
                        alt={brand.name}
                        width={48}
                        height={48}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 truncate">{brand.name}</p>
                      <p className="text-xs text-gray-500 truncate">{brand.nameEN}</p>
                      <p className="text-xs text-gray-400 mt-1">
                        {brand.viewedAt ? new Date(brand.viewedAt).toLocaleDateString() : ""}
                      </p>
                    </div>
                    {loadingBrandId === brand.id && (
                      <div className="w-4 h-4 border-2 border-pink-300 border-t-pink-500 rounded-full animate-spin flex-shrink-0"></div>
                    )}
                  </div>
                </motion.button>
              ))}
            </div>
          </div>
        )

      case "categories":
        return <BrandCategoryList onBrandClick={handleBrandClick} loadingBrandId={loadingBrandId} />
    }
  }

  const tabs = [
    { id: "keywords" as TabType, label: "추천 키워드", icon: Star },
    { id: "popular" as TabType, label: "인기 브랜드", icon: TrendingUp },
    { id: "recent" as TabType, label: "최근 본 브랜드", icon: Clock },
    { id: "categories" as TabType, label: "브랜드 목록", icon: List },
  ]

  return (
    <div className="min-h-screen bg-white">
      {/* Full Screen Loader */}
      {isNavigating && <FullScreenLoader />}

      {/* Header */}
      <div className="flex items-center p-4 border-b border-gray-200 sticky top-0 bg-white shadow-sm z-40">
        <button onClick={handleBack} className="p-2 hover:bg-gray-100 rounded-full mr-2">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-lg font-semibold">검색</h1>
      </div>

      {/* Sticky Search Bar */}
      <div className="sticky top-16 z-30 bg-white p-4 border-b border-gray-100 shadow-sm">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            ref={inputRef}
            type="text"
            placeholder="브랜드명/카테고리를 검색해보세요"
            className="w-full pl-12 pr-4 py-2 border border-pink-300 rounded-full shadow-md focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent transition-all"
            value={searchQuery}
            onChange={handleInputChange}
            onKeyDown={handleKeyDown}
            autoFocus
          />
          {searchQuery && (
            <button
              onClick={handleClearSearch}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 hover:text-gray-600"
            >
              ×
            </button>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {searchQuery ? (
          // Search Results
          <>
            <div className="mb-6">
              <h2 className="text-lg font-semibold mb-4">`"{searchQuery}" 검색 결과`</h2>
              <p className="text-sm text-gray-500 mb-4">
                {isLoading ? "검색 중..." : `${filteredBrands.length}개의 브랜드를 찾았습니다`}
              </p>
            </div>

            {/* Loading State */}
            {isLoading && <SearchSkeleton />}

            {/* Brand Grid */}
            {!isLoading && filteredBrands.length > 0 && (
              <AnimatePresence mode="wait">
                <motion.div
                  key={debouncedSearchQuery}
                  className="grid grid-cols-2 gap-4"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  {filteredBrands.map((brand, index) => (
                    <motion.button
                      key={brand.id}
                      ref={(el) => {
                        brandRefs.current[index] = el
                      }}
                      className={`min-h-12 p-4 bg-white border rounded-lg shadow hover:shadow-md transition-all duration-200 text-left outline-none ${
                        selectedIndex === index
                          ? "border-pink-500 bg-pink-50 ring-2 ring-pink-200"
                          : "border-gray-200 hover:border-pink-300"
                      }`}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                      whileHover={{ scale: selectedIndex === index ? 1 : 1.05 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => handleBrandClick(brand)}
                      onMouseEnter={() => setSelectedIndex(index)}
                      onMouseLeave={() => setSelectedIndex(-1)}
                      disabled={loadingBrandId === brand.id}
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-12 h-12 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                          <Image
                            src={brand.image || "/placeholder.svg"}
                            alt={brand.name}
                            width={48}
                            height={48}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900 truncate">{brand.name}</p>
                          <p className="text-xs text-gray-500 truncate">{brand.nameEN}</p>
                          <p className="text-xs text-pink-500 mt-1">{brand.category}</p>
                        </div>
                        {loadingBrandId === brand.id && (
                          <div className="w-4 h-4 border-2 border-pink-300 border-t-pink-500 rounded-full animate-spin flex-shrink-0"></div>
                        )}
                      </div>
                    </motion.button>
                  ))}
                </motion.div>
              </AnimatePresence>
            )}

            {/* Empty State */}
            {!isLoading && filteredBrands.length === 0 && (
              <EmptyState type="search" onAction={handleClearSearch} actionLabel="전체 브랜드 보기" />
            )}
          </>
        ) : (
          // Recommendation Tabs
          <>
            {/* Tab Navigation */}
            <div className="flex border-b border-gray-200 mb-6 sticky top-32 bg-white shadow-sm z-20 -mx-4 px-4 py-2">
              {tabs.map((tab) => {
                const Icon = tab.icon
                return (
                  <button
                    key={tab.id}
                    className={`flex-1 text-sm font-medium py-3 px-2 border-b-2 transition-colors min-h-12 ${
                      activeTab === tab.id
                        ? "border-pink-500 text-pink-600"
                        : "border-transparent text-gray-500 hover:border-pink-400 hover:text-gray-700"
                    }`}
                    onClick={() => setActiveTab(tab.id)}
                  >
                    <div className="flex items-center justify-center space-x-1">
                      <Icon className="w-4 h-4" />
                      <span>{tab.label}</span>
                    </div>
                  </button>
                )
              })}
            </div>

            {/* Tab Content */}
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                {getTabContent()}
              </motion.div>
            </AnimatePresence>
          </>
        )}

        {/* Keyboard Navigation Hint */}
        {((searchQuery && filteredBrands.length > 0) || (!searchQuery && getCurrentItems().length > 0)) &&
          !isLoading &&
          !tabLoading &&
          activeTab !== "categories" && (
            <div className="mt-8 p-3 bg-gray-50 rounded-lg">
              <p className="text-xs text-gray-500 text-center">↑↓ 키로 선택, Enter로 이동, Esc로 선택 해제</p>
            </div>
          )}
      </div>
    </div>
  )
}
