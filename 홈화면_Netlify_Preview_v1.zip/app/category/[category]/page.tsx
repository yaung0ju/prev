"use client"

import { useState, useEffect, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ArrowLeft, Search, User, ChevronDown, Filter, Grid, List, ChevronLeft, ChevronRight } from "lucide-react"
import { useRouter, useParams } from "next/navigation"
import ProductCard from "@/components/product-card"
import BottomNav from "@/components/bottom-nav"
import CategorySidebar from "@/components/category-sidebar"
import SearchModal from "@/components/search-modal"

// Mock data for category products
const categoryData = {
  가방: {
    name: "BAG",
    koreanName: "가방",
    subcategories: [
      { id: "all", name: "전체", count: 1250 },
      { id: "tote", name: "토트", count: 245 },
      { id: "crossbody", name: "크로스/숄더", count: 189 },
      { id: "hobo", name: "호보/버킷", count: 156 },
      { id: "mini", name: "미니/백팩", count: 134 },
      { id: "clutch", name: "클러치/파우치", count: 98 },
      { id: "wallet", name: "지갑", count: 167 },
    ],
    topPicks: [
      {
        id: 1,
        name: "클래식 퀼팅 체인백",
        brand: "CHANEL",
        price: 6500000,
        originalPrice: 7200000,
        images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
        isLiked: false,
      },
      {
        id: 2,
        name: "미니 크로스백",
        brand: "LOUIS VUITTON",
        price: 2900000,
        images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
        isLiked: true,
      },
      {
        id: 3,
        name: "레더 토트백",
        brand: "HERMÈS",
        price: 8900000,
        images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
        isLiked: false,
      },
      {
        id: 4,
        name: "버킷백",
        brand: "CELINE",
        price: 2800000,
        images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
        isLiked: true,
      },
      {
        id: 5,
        name: "클러치백",
        brand: "BOTTEGA VENETA",
        price: 2100000,
        images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
        isLiked: false,
      },
    ],
    products: [
      {
        id: 6,
        name: "스몰 숄더백",
        brand: "BOTTEGA VENETA",
        price: 3200000,
        images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
        isLiked: true,
      },
      {
        id: 7,
        name: "백팩",
        brand: "PRADA",
        price: 2900000,
        images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
        isLiked: false,
      },
      {
        id: 8,
        name: "미디움 토트백",
        brand: "GUCCI",
        price: 4200000,
        images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
        isLiked: true,
      },
      {
        id: 9,
        name: "체인 숄더백",
        brand: "CHANEL",
        price: 5800000,
        images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
        isLiked: false,
      },
      {
        id: 10,
        name: "크로스백",
        brand: "LOUIS VUITTON",
        price: 3500000,
        images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
        isLiked: true,
      },
      {
        id: 11,
        name: "미니 핸드백",
        brand: "HERMÈS",
        price: 7200000,
        images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
        isLiked: false,
      },
      {
        id: 12,
        name: "레더 클러치",
        brand: "BOTTEGA VENETA",
        price: 1800000,
        images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
        isLiked: true,
      },
      {
        id: 13,
        name: "체인 백팩",
        brand: "PRADA",
        price: 3800000,
        images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
        isLiked: false,
      },
    ],
  },
  주얼리: {
    name: "JEWELRY",
    koreanName: "주얼리",
    subcategories: [
      { id: "all", name: "전체", count: 890 },
      { id: "ring", name: "반지", count: 312 },
      { id: "earring", name: "귀걸이", count: 278 },
      { id: "necklace", name: "목걸이", count: 245 },
      { id: "bracelet", name: "팔찌", count: 189 },
      { id: "brooch", name: "브로치", count: 45 },
    ],
    topPicks: [
      {
        id: 21,
        name: "다이아몬드 반지",
        brand: "TIFFANY & CO.",
        price: 8900000,
        images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
        isLiked: false,
      },
      {
        id: 22,
        name: "골드 체인 목걸이",
        brand: "CARTIER",
        price: 1200000,
        images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
        isLiked: true,
      },
      {
        id: 23,
        name: "진주 귀걸이",
        brand: "CHANEL",
        price: 1800000,
        images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
        isLiked: false,
      },
    ],
    products: [
      {
        id: 24,
        name: "실버 브레이슬릿",
        brand: "TIFFANY & CO.",
        price: 890000,
        images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
        isLiked: true,
      },
      {
        id: 25,
        name: "골드 링",
        brand: "CARTIER",
        price: 2800000,
        originalPrice: 3200000,
        images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
        isLiked: false,
      },
    ],
  },
  시계: {
    name: "TIMEPIECE",
    koreanName: "시계",
    subcategories: [
      { id: "all", name: "전체", count: 345 },
      { id: "women", name: "여성시계", count: 189 },
      { id: "men", name: "남성시계", count: 156 },
    ],
    topPicks: [
      {
        id: 31,
        name: "클래식 워치",
        brand: "ROLEX",
        price: 12000000,
        images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
        isLiked: false,
      },
      {
        id: 32,
        name: "골드 시계",
        brand: "OMEGA",
        price: 8500000,
        images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
        isLiked: true,
      },
    ],
    products: [
      {
        id: 33,
        name: "스틸 워치",
        brand: "CARTIER",
        price: 6800000,
        images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
        isLiked: false,
      },
    ],
  },
}

const brands = [
  "ALL BRAND",
  "CHANEL",
  "LOUIS VUITTON",
  "HERMÈS",
  "GUCCI",
  "PRADA",
  "BOTTEGA VENETA",
  "TIFFANY & CO.",
  "CARTIER",
]

const sortOptions = [
  { id: "popular", name: "인기순" },
  { id: "newest", name: "신상품순" },
  { id: "price-low", name: "낮은가격순" },
  { id: "price-high", name: "높은가격순" },
  { id: "discount", name: "할인율순" },
]

export default function CategoryPage() {
  const router = useRouter()
  const params = useParams()
  const category = params.category as string

  const [selectedBrand, setSelectedBrand] = useState("ALL BRAND")
  const [selectedSubcategory, setSelectedSubcategory] = useState("all")
  const [selectedSort, setSelectedSort] = useState("popular")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [showBrandDropdown, setShowBrandDropdown] = useState(false)
  const [showSortDropdown, setShowSortDropdown] = useState(false)
  const [visibleProducts, setVisibleProducts] = useState(20)
  const [isCategorySidebarOpen, setIsCategorySidebarOpen] = useState(false)
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false)
  const [activeBottomNav, setActiveBottomNav] = useState("카테고리")
  const [currentTopPickSlide, setCurrentTopPickSlide] = useState(0)
  const topPicksRef = useRef<HTMLDivElement>(null)

  const currentCategory = categoryData[category as keyof typeof categoryData]

  useEffect(() => {
    if (!currentCategory) {
      router.push("/")
    }
  }, [currentCategory, router])

  // Auto slide for TOP PICKS
  useEffect(() => {
    if (!currentCategory?.topPicks) return

    const interval = setInterval(() => {
      setCurrentTopPickSlide((prev) => (prev + 1) % Math.ceil(currentCategory.topPicks.length / 2))
    }, 4000)

    return () => clearInterval(interval)
  }, [currentCategory?.topPicks])

  if (!currentCategory) {
    return null
  }

  const handleBack = () => {
    router.back()
  }

  const handleSubcategoryClick = (subcategoryId: string) => {
    setSelectedSubcategory(subcategoryId)
    setVisibleProducts(20)
  }

  const handleLoadMore = () => {
    setVisibleProducts((prev) => prev + 20)
  }

  const nextTopPickSlide = () => {
    setCurrentTopPickSlide((prev) => (prev + 1) % Math.ceil(currentCategory.topPicks.length / 2))
  }

  const prevTopPickSlide = () => {
    setCurrentTopPickSlide(
      (prev) =>
        (prev - 1 + Math.ceil(currentCategory.topPicks.length / 2)) % Math.ceil(currentCategory.topPicks.length / 2),
    )
  }

  const filteredProducts = currentCategory.products.slice(0, visibleProducts)

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white border-b border-gray-200">
        {/* Top Header */}
        <div className="flex items-center justify-between px-4 h-14">
          <div className="flex items-center space-x-4">
            <button onClick={handleBack} className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
              <ArrowLeft className="w-5 h-5" />
            </button>

            {/* Brand Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowBrandDropdown(!showBrandDropdown)}
                className="flex items-center space-x-2 px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded-xl transition-colors"
              >
                <span className="text-sm font-medium">{selectedBrand}</span>
                <ChevronDown className="w-4 h-4" />
              </button>

              <AnimatePresence>
                {showBrandDropdown && (
                  <motion.div
                    className="absolute top-full left-0 mt-2 w-48 bg-white border border-gray-200 rounded-xl shadow-lg z-50 max-h-60 overflow-y-auto"
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                  >
                    {brands.map((brand) => (
                      <button
                        key={brand}
                        onClick={() => {
                          setSelectedBrand(brand)
                          setShowBrandDropdown(false)
                        }}
                        className="w-full px-4 py-3 text-left hover:bg-gray-50 first:rounded-t-xl last:rounded-b-xl transition-colors"
                      >
                        <span className="text-sm">{brand}</span>
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setIsSearchModalOpen(true)}
              className="p-2 hover:bg-gray-100 rounded-xl transition-colors"
            >
              <Search className="w-5 h-5" />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
              <User className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="px-4 py-2 overflow-x-auto">
          <div className="flex space-x-1 min-w-max">
            {Object.keys(categoryData).map((cat) => (
              <button
                key={cat}
                onClick={() => router.push(`/category/${cat}`)}
                className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors whitespace-nowrap ${
                  cat === category ? "bg-pink-500 text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                {categoryData[cat as keyof typeof categoryData].koreanName}
              </button>
            ))}
          </div>
        </div>
      </div>

      <main className="pb-20">
        {/* TOP PICKS Section */}
        <section className="py-6 bg-gray-50">
          <div className="px-4">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">{currentCategory.name}</h2>
                <p className="text-sm text-pink-500">자동슬라이드, Max 30개상품</p>
              </div>
            </div>

            {/* Top Picks Auto Slider */}
            <div className="relative">
              <div className="overflow-hidden rounded-2xl">
                <div
                  className="flex transition-transform duration-500 ease-in-out"
                  style={{ transform: `translateX(-${currentTopPickSlide * 100}%)` }}
                >
                  {Array.from({ length: Math.ceil(currentCategory.topPicks.length / 2) }).map((_, slideIndex) => (
                    <div key={slideIndex} className="w-full flex-shrink-0">
                      <div className="grid grid-cols-2 gap-4 px-2">
                        {currentCategory.topPicks.slice(slideIndex * 2, slideIndex * 2 + 2).map((product, index) => (
                          <motion.div
                            key={product.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.3, delay: index * 0.1 }}
                          >
                            <ProductCard {...product} />
                          </motion.div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Navigation buttons */}
              {Math.ceil(currentCategory.topPicks.length / 2) > 1 && (
                <>
                  <button
                    onClick={prevTopPickSlide}
                    className="absolute left-2 top-1/2 -translate-y-1/2 w-10 h-10 bg-white shadow-lg rounded-full flex items-center justify-center hover:bg-gray-50 transition-colors z-10"
                  >
                    <ChevronLeft className="w-5 h-5 text-gray-600" />
                  </button>
                  <button
                    onClick={nextTopPickSlide}
                    className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 bg-white shadow-lg rounded-full flex items-center justify-center hover:bg-gray-50 transition-colors z-10"
                  >
                    <ChevronRight className="w-5 h-5 text-gray-600" />
                  </button>
                </>
              )}

              {/* Dots indicator */}
              {Math.ceil(currentCategory.topPicks.length / 2) > 1 && (
                <div className="flex justify-center mt-4 space-x-2">
                  {Array.from({ length: Math.ceil(currentCategory.topPicks.length / 2) }).map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentTopPickSlide(index)}
                      className={`w-2 h-2 rounded-full transition-all ${
                        index === currentTopPickSlide ? "bg-pink-500 w-6" : "bg-gray-300"
                      }`}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
        </section>

        {/* Subcategory Filters */}
        <section className="py-4 bg-white border-b border-gray-200">
          <div className="px-4">
            <div className="flex space-x-2 overflow-x-auto pb-2">
              {currentCategory.subcategories.map((subcategory) => (
                <button
                  key={subcategory.id}
                  onClick={() => handleSubcategoryClick(subcategory.id)}
                  className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors whitespace-nowrap ${
                    selectedSubcategory === subcategory.id
                      ? "bg-pink-500 text-white"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  {subcategory.name}
                  <span className="ml-1 text-xs opacity-75">({subcategory.count})</span>
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Sort & View Options */}
        <section className="py-3 bg-white border-b border-gray-100">
          <div className="px-4 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              {/* Sort Dropdown */}
              <div className="relative">
                <button
                  onClick={() => setShowSortDropdown(!showSortDropdown)}
                  className="flex items-center space-x-2 px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded-xl transition-colors"
                >
                  <Filter className="w-4 h-4" />
                  <span className="text-sm">{sortOptions.find((opt) => opt.id === selectedSort)?.name}</span>
                  <ChevronDown className="w-4 h-4" />
                </button>

                <AnimatePresence>
                  {showSortDropdown && (
                    <motion.div
                      className="absolute top-full left-0 mt-2 w-40 bg-white border border-gray-200 rounded-xl shadow-lg z-50"
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                    >
                      {sortOptions.map((option) => (
                        <button
                          key={option.id}
                          onClick={() => {
                            setSelectedSort(option.id)
                            setShowSortDropdown(false)
                          }}
                          className="w-full px-4 py-3 text-left hover:bg-gray-50 first:rounded-t-xl last:rounded-b-xl transition-colors"
                        >
                          <span className="text-sm">{option.name}</span>
                        </button>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <span className="text-sm text-gray-500">총 {currentCategory.products.length}개 상품</span>
            </div>

            {/* View Mode Toggle */}
            <div className="flex items-center space-x-1 bg-gray-100 rounded-xl p-1">
              <button
                onClick={() => setViewMode("grid")}
                className={`p-2 rounded-lg transition-colors ${
                  viewMode === "grid" ? "bg-white shadow-sm" : "hover:bg-gray-200"
                }`}
              >
                <Grid className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode("list")}
                className={`p-2 rounded-lg transition-colors ${
                  viewMode === "list" ? "bg-white shadow-sm" : "hover:bg-gray-200"
                }`}
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          </div>
        </section>

        {/* Products Grid */}
        <section className="py-6">
          <div className="px-4">
            <div
              className={`grid gap-4 ${
                viewMode === "grid" ? "grid-cols-2 md:grid-cols-3 lg:grid-cols-4" : "grid-cols-1 md:grid-cols-2"
              }`}
            >
              {filteredProducts.map((product, index) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.05 }}
                  className={viewMode === "list" ? "flex" : ""}
                >
                  <ProductCard {...product} />
                </motion.div>
              ))}
            </div>

            {/* Load More Button */}
            {visibleProducts < currentCategory.products.length && (
              <div className="text-center mt-8">
                <motion.button
                  onClick={handleLoadMore}
                  className="px-8 py-3 bg-gray-900 text-white rounded-xl hover:bg-gray-800 transition-colors font-medium"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  MORE ({visibleProducts}/{currentCategory.products.length})
                </motion.button>
              </div>
            )}
          </div>
        </section>

        {/* ITEM FOR YOU Section */}
        <section className="py-8 bg-gray-50">
          <div className="px-4">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-xl font-bold text-gray-900">ITEM FOR YOU</h3>
                <p className="text-sm text-pink-500">추천아이템, Max 30개상품</p>
              </div>
              <button className="text-pink-500 hover:text-pink-600 font-medium text-sm">전체보기</button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {currentCategory.topPicks.slice(0, 6).map((product, index) => (
                <motion.div
                  key={`item-for-you-${product.id}`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                >
                  <ProductCard {...product} />
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* TRENDING NOW Section */}
        <section className="py-8 bg-white">
          <div className="px-4">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-xl font-bold text-gray-900">TRENDING NOW</h3>
                <p className="text-sm text-pink-500">추천아이템, Max 30개</p>
              </div>
              <button className="text-pink-500 hover:text-pink-600 font-medium text-sm">전체보기</button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {currentCategory.products.slice(0, 6).map((product, index) => (
                <motion.div
                  key={`trending-${product.id}`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                >
                  <ProductCard {...product} />
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* COMMUNITY Section */}
        <section className="py-8 bg-gray-50">
          <div className="px-4">
            <h3 className="text-xl font-bold text-gray-900 mb-6">COMMUNITY</h3>
            <div className="bg-white rounded-xl p-6 text-center">
              <p className="text-gray-600 mb-4">커뮤니티 콘텐츠</p>
              <p className="text-sm text-gray-500">MON to FRI | 9am - 6pm</p>
            </div>
          </div>
        </section>
      </main>

      <CategorySidebar isOpen={isCategorySidebarOpen} onClose={() => setIsCategorySidebarOpen(false)} />
      <SearchModal isOpen={isSearchModalOpen} onClose={() => setIsSearchModalOpen(false)} />

      <BottomNav
        activeMenu={activeBottomNav}
        onMenuClick={setActiveBottomNav}
        onCategoryClick={() => setIsCategorySidebarOpen(true)}
      />
    </div>
  )
}
