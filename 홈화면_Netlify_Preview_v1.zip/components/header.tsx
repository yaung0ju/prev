"use client"

import { useState, useEffect, useRef } from "react"
import { Search, ShoppingCart, ChevronDown } from "lucide-react"
import { motion } from "framer-motion"
import { useRouter } from "next/navigation"
import BrandMegaPanel from "./brand-mega-panel"
import SearchOverlay from "./search-overlay"
import CategoryMegaPanel from "./category-mega-panel"

interface HeaderProps {
  onSearchClick: () => void
  onCategoryClick?: () => void // 선택적으로 변경
}

const categories = ["가방", "주얼리", "시계", "여성패션", "남성패션", "오뜨펫", "키즈", "메종", "커뮤니티"]

export default function Header({ onSearchClick, onCategoryClick }: HeaderProps) {
  const [isBrandPanelOpen, setIsBrandPanelOpen] = useState(false)
  const [isSearchOverlayOpen, setIsSearchOverlayOpen] = useState(false)
  const [isCategoryPanelOpen, setIsCategoryPanelOpen] = useState(false)
  const [activeCategory, setActiveCategory] = useState<string | null>(null)
  const [hoverTimeout, setHoverTimeout] = useState<NodeJS.Timeout | null>(null)
  const headerRef = useRef<HTMLElement>(null)
  const router = useRouter()

  // Close panels when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (headerRef.current && !headerRef.current.contains(event.target as Node)) {
        setIsBrandPanelOpen(false)
        setIsCategoryPanelOpen(false)
        setActiveCategory(null)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  const handleSearchClick = () => {
    setIsBrandPanelOpen(false)
    setIsCategoryPanelOpen(false)
    setIsSearchOverlayOpen(true)
  }

  const handleBrandPanelToggle = () => {
    setIsSearchOverlayOpen(false)
    setIsCategoryPanelOpen(false)
    setIsBrandPanelOpen(!isBrandPanelOpen)
  }

  const handleTopFloorClick = () => {
    router.push("/")
  }

  const handleBrandClick = (brand: any) => {
    console.log(`Navigate to ${brand.name} page`)
    // router.push(`/brand/${brand.id}`)
  }

  const handleCategoryClick = (category: string) => {
    setIsBrandPanelOpen(false)
    setIsSearchOverlayOpen(false)
    // Always navigate to category page
    router.push(`/category/${category}`)
  }

  const handleCategoryHover = (category: string) => {
    // Clear existing timeout
    if (hoverTimeout) {
      clearTimeout(hoverTimeout)
    }

    // Only on desktop
    if (window.innerWidth >= 768) {
      setIsBrandPanelOpen(false)
      setIsSearchOverlayOpen(false)
      setActiveCategory(category)
      setIsCategoryPanelOpen(true)
    }
  }

  const handleCategoryLeave = () => {
    // Set timeout to close panel after delay
    const timeout = setTimeout(() => {
      setIsCategoryPanelOpen(false)
      setActiveCategory(null)
    }, 300)
    setHoverTimeout(timeout)
  }

  const handlePanelHover = () => {
    // Clear timeout when hovering over panel
    if (hoverTimeout) {
      clearTimeout(hoverTimeout)
    }
  }

  const closeCategoryPanel = () => {
    setIsCategoryPanelOpen(false)
    setActiveCategory(null)
  }

  const handleSubcategoryClick = (categoryId: string, subcategoryId: string) => {
    console.log(`Navigate to ${categoryId}/${subcategoryId}`)
    router.push(`/category/${categoryId}?subcategory=${subcategoryId}`)
  }

  const handleCategoryPageClick = (categoryId: string) => {
    console.log(`Navigate to ${categoryId} page`)
    router.push(`/category/${categoryId}`)
  }

  const handleBrandPageClick = (brandId: number) => {
    console.log(`Navigate to brand ${brandId}`)
    // router.push(`/brand/${brandId}`)
  }

  return (
    <header ref={headerRef} className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-40 relative">
      {/* Top Header */}
      <div className="flex justify-between items-center px-4 h-16">
        <div className="flex items-center space-x-2">
          <motion.button
            className="text-2xl font-bold text-black hover:text-gray-700 transition-colors"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            onClick={handleTopFloorClick}
          >
            TOP FLOOR
          </motion.button>

          <motion.button
            className="p-1 hover:text-pink-500 transition-all duration-300 opacity-30 hover:opacity-100"
            onClick={handleBrandPanelToggle}
            aria-label="브랜드 목록"
          >
            <motion.div animate={{ rotate: isBrandPanelOpen ? 180 : 0 }} transition={{ duration: 0.2 }}>
              <ChevronDown className="w-4 h-4 text-gray-600 hover:text-pink-500 transition-colors" />
            </motion.div>
          </motion.button>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={handleSearchClick}
            className="p-2 hover:bg-gray-100 rounded-xl transition-all duration-300 opacity-30 hover:opacity-100 shadow-sm"
            aria-label="검색"
          >
            <Search className="w-6 h-6 text-gray-700" />
          </button>
          <button
            className="p-2 hover:bg-gray-100 rounded-xl transition-all duration-300 opacity-30 hover:opacity-100 shadow-sm"
            aria-label="장바구니"
          >
            <ShoppingCart className="w-6 h-6 text-gray-700" />
          </button>
        </div>
      </div>

      {/* Category Navigation - Desktop */}
      <div className="hidden md:block px-2 py-2 overflow-x-auto">
        <div className="flex justify-between items-center min-w-max px-2">
          {categories.map((category, index) => (
            <motion.button
              key={category}
              className={`text-sm whitespace-nowrap py-3 px-4 transition-all duration-300 flex-1 text-center border-b-2 rounded-xl opacity-30 hover:opacity-100 ${
                activeCategory === category && isCategoryPanelOpen
                  ? "text-pink-500 border-pink-500 bg-pink-50 opacity-100"
                  : "text-gray-700 border-transparent hover:text-pink-500 hover:border-pink-300 hover:bg-pink-50"
              }`}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 0.3, y: 0 }}
              whileHover={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
              onClick={() => handleCategoryClick(category)}
              onMouseEnter={() => handleCategoryHover(category)}
              onMouseLeave={handleCategoryLeave}
            >
              {category}
            </motion.button>
          ))}
        </div>
      </div>

      {/* Category Navigation - Mobile (Horizontal Scroll) */}
      <div className="md:hidden px-2 py-2 overflow-x-auto">
        <div className="flex space-x-1 min-w-max px-2">
          {categories.slice(0, 6).map((category, index) => (
            <motion.button
              key={category}
              className="text-xs text-gray-700 hover:text-pink-500 whitespace-nowrap py-2 px-3 bg-gray-100 hover:bg-pink-100 rounded-xl transition-all duration-300 flex-shrink-0 opacity-30 hover:opacity-100 shadow-sm"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 0.3, y: 0 }}
              whileHover={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
              onClick={() => handleCategoryClick(category)}
            >
              {category}
            </motion.button>
          ))}
        </div>
      </div>

      {/* Bottom border */}
      <div className="h-px bg-black"></div>

      {/* Brand Mega Panel */}
      <BrandMegaPanel
        isOpen={isBrandPanelOpen}
        onClose={() => setIsBrandPanelOpen(false)}
        onBrandClick={handleBrandClick}
      />

      {/* Category Mega Panel - Desktop Only */}
      <div className="hidden md:block" onMouseEnter={handlePanelHover} onMouseLeave={handleCategoryLeave}>
        <CategoryMegaPanel
          isOpen={isCategoryPanelOpen}
          activeCategory={activeCategory}
          onClose={closeCategoryPanel}
          onCategoryClick={handleCategoryPageClick}
          onSubcategoryClick={handleSubcategoryClick}
          onBrandClick={handleBrandPageClick}
        />
      </div>

      {/* Search Overlay */}
      <SearchOverlay isOpen={isSearchOverlayOpen} onClose={() => setIsSearchOverlayOpen(false)} />
    </header>
  )
}
