"use client"

import { motion } from "framer-motion"

export default function Footer() {
  return (
    <footer className="bg-gray-50 border-t border-gray-200 py-8 mt-20">
      <div className="max-w-[1440px] mx-auto px-4 md:px-8">
        <motion.div
          className="text-center space-y-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex justify-center space-x-6 text-sm text-gray-600">
            <button className="hover:text-pink-500 transition-colors">이용약관</button>
            <button className="hover:text-pink-500 transition-colors font-semibold">개인정보처리방침</button>
          </div>

          <div className="text-xs text-gray-500 space-y-1">
            <p>TOP FLOOR</p>
            <p>고객센터: 1588-0000 | 평일 09:00-18:00</p>
            <p>© 2024 TOP FLOOR. All rights reserved.</p>
          </div>
        </motion.div>
      </div>
    </footer>
  )
}
