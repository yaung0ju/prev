"use client"

import { motion } from "framer-motion"
import ProductCard from "./product-card"

const newArrivalProducts = [
  {
    id: 1,
    name: "클래식 퀼팅 체인백",
    brand: "CHANEL",
    price: 6500000,
    originalPrice: 7200000,
    images: [
      "/placeholder.svg?height=400&width=300",
      "/placeholder.svg?height=400&width=300&text=2",
      "/placeholder.svg?height=400&width=300&text=3",
    ],
    isLiked: false,
    isNew: true,
  },
  {
    id: 2,
    name: "골드 체인 목걸이",
    brand: "TIFFANY & CO.",
    price: 1800000,
    images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
    isLiked: true,
    isNew: true,
  },
  {
    id: 3,
    name: "미니 크로스백",
    brand: "LOUIS VUITTON",
    price: 2900000,
    images: [
      "/placeholder.svg?height=400&width=300",
      "/placeholder.svg?height=400&width=300&text=2",
      "/placeholder.svg?height=400&width=300&text=3",
      "/placeholder.svg?height=400&width=300&text=4",
    ],
    isLiked: false,
    isNew: true,
  },
  {
    id: 4,
    name: "다이아몬드 브레이슬릿",
    brand: "CARTIER",
    price: 4200000,
    originalPrice: 4800000,
    images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
    isLiked: false,
    isNew: true,
  },
  {
    id: 5,
    name: "레더 토트백",
    brand: "HERMÈS",
    price: 8900000,
    images: [
      "/placeholder.svg?height=400&width=300",
      "/placeholder.svg?height=400&width=300&text=2",
      "/placeholder.svg?height=400&width=300&text=3",
    ],
    isLiked: true,
    isNew: true,
  },
  {
    id: 6,
    name: "실버 링",
    brand: "TIFFANY & CO.",
    price: 890000,
    images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
    isLiked: false,
    isNew: true,
  },
  {
    id: 7,
    name: "스몰 숄더백",
    brand: "BOTTEGA VENETA",
    price: 3200000,
    images: [
      "/placeholder.svg?height=400&width=300",
      "/placeholder.svg?height=400&width=300&text=2",
      "/placeholder.svg?height=400&width=300&text=3",
    ],
    isLiked: true,
    isNew: true,
  },
  {
    id: 8,
    name: "골드 이어링",
    brand: "CHANEL",
    price: 2100000,
    images: ["/placeholder.svg?height=400&width=300", "/placeholder.svg?height=400&width=300&text=2"],
    isLiked: false,
    isNew: true,
  },
]

export default function NewArrivalSection() {
  // Safe data filtering - remove null/undefined/empty objects
  const safeProducts = newArrivalProducts.filter((product) => {
    return (
      product &&
      typeof product === "object" &&
      product.id &&
      product.name &&
      product.brand &&
      typeof product.price === "number" &&
      product.price > 0
    )
  })

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <motion.div
          className="flex justify-between items-center mb-8"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">NEW ARRIVAL</h2>
            <p className="text-gray-600">지금 막 도착한 최신 컬렉션을 만나보세요</p>
          </div>
          <button className="text-pink-500 hover:text-pink-600 font-medium transition-colors">전체보기</button>
        </motion.div>

        {/* Grid Layout - PC: 4 columns, Mobile: 2 columns */}
        <motion.div
          className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-4 auto-rows-max"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          {safeProducts.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <ProductCard {...product} showImageNavigation={true} />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
