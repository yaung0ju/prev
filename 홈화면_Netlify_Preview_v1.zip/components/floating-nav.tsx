"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronUp, X, Trash2 } from "lucide-react"
import Image from "next/image"
import { useRecentProducts } from "@/hooks/useRecentProducts"

export default function FloatingNav() {
  const [isVisible, setIsVisible] = useState(false)
  const [scrollTimeout, setScrollTimeout] = useState<NodeJS.Timeout | null>(null)
  const [showRecentProducts, setShowRecentProducts] = useState(false)
  const { recentProducts, removeRecentProduct, clearRecentProducts } = useRecentProducts()

  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY

      // Show when scrolled down more than 300px
      if (scrollY > 300) {
        setIsVisible(true)

        // Clear existing timeout
        if (scrollTimeout) {
          clearTimeout(scrollTimeout)
        }

        // Set new timeout to hide after 3 seconds of no scrolling
        const timeout = setTimeout(() => {
          setIsVisible(false)
        }, 3000)

        setScrollTimeout(timeout)
      } else {
        setIsVisible(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => {
      window.removeEventListener("scroll", handleScroll)
      if (scrollTimeout) {
        clearTimeout(scrollTimeout)
      }
    }
  }, [scrollTimeout])

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const handleKakaoChat = () => {
    window.open("https://open.kakao.com/o/sAoayerh", "_blank")
  }

  const handleRecentProductClick = (productId: number) => {
    console.log(`Navigate to product ${productId}`)
    setShowRecentProducts(false)
  }

  const handleRemoveProduct = (e: React.MouseEvent, productId: number) => {
    e.stopPropagation()
    removeRecentProduct(productId)
  }

  const handleClearAll = () => {
    clearRecentProducts()
    setShowRecentProducts(false)
  }

  const toggleRecentProducts = () => {
    setShowRecentProducts(!showRecentProducts)
  }

  return (
    <div className="fixed bottom-20 right-4 z-50">
      {/* Recent Products Panel */}
      <AnimatePresence>
        {showRecentProducts && (
          <motion.div
            className="mb-3 bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden w-80 max-w-[calc(100vw-2rem)]"
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            transition={{ duration: 0.3 }}
          >
            <div className="p-3 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-medium text-gray-900">최근 본 상품 ({recentProducts.length})</h3>
                <div className="flex items-center space-x-1">
                  {recentProducts.length > 0 && (
                    <button
                      onClick={handleClearAll}
                      className="p-1 hover:bg-gray-100 rounded-xl transition-colors"
                      title="전체 삭제"
                    >
                      <Trash2 className="w-3 h-3 text-gray-400" />
                    </button>
                  )}
                  <button
                    onClick={() => setShowRecentProducts(false)}
                    className="p-1 hover:bg-gray-100 rounded-xl transition-colors"
                  >
                    <X className="w-3 h-3 text-gray-400" />
                  </button>
                </div>
              </div>
            </div>

            <div className="max-h-80 overflow-y-auto">
              {recentProducts.length > 0 ? (
                recentProducts.map((product, index) => (
                  <motion.div
                    key={`${product.id}-${product.viewedAt}`}
                    className="relative group"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.2, delay: index * 0.05 }}
                  >
                    <button
                      className="w-full p-3 hover:bg-gray-50 transition-colors text-left border-b border-gray-50 last:border-b-0"
                      onClick={() => handleRecentProductClick(product.id)}
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-12 h-12 bg-gray-100 rounded-xl overflow-hidden flex-shrink-0">
                          <Image
                            src={product.image || "/placeholder.svg"}
                            alt={product.name}
                            width={48}
                            height={48}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-medium text-gray-900 truncate">{product.name}</p>
                          <p className="text-xs text-gray-500 truncate">{product.brand}</p>
                          <div className="flex items-center space-x-1 mt-1">
                            <p className="text-xs font-medium text-pink-600">₩{product.price.toLocaleString()}</p>
                            {product.originalPrice && (
                              <p className="text-xs text-gray-400 line-through">
                                ₩{product.originalPrice.toLocaleString()}
                              </p>
                            )}
                          </div>
                          <p className="text-xs text-gray-400 mt-1">
                            {new Date(product.viewedAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    </button>

                    {/* Individual Remove Button */}
                    <button
                      onClick={(e) => handleRemoveProduct(e, product.id)}
                      className="absolute top-2 right-2 p-1 bg-white bg-opacity-80 hover:bg-opacity-100 rounded-xl shadow-sm opacity-0 group-hover:opacity-100 transition-all duration-200"
                      title="삭제"
                    >
                      <X className="w-3 h-3 text-gray-400 hover:text-red-500" />
                    </button>
                  </motion.div>
                ))
              ) : (
                <div className="p-6 text-center">
                  <div className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                    <span className="text-gray-400 text-lg">👀</span>
                  </div>
                  <p className="text-sm text-gray-500 mb-2">최근 본 상품이 없습니다</p>
                  <p className="text-xs text-gray-400">상품을 클릭하면 여기에 표시됩니다</p>
                </div>
              )}
            </div>

            {recentProducts.length > 0 && (
              <div className="p-3 border-t border-gray-100 bg-gray-50">
                <button
                  onClick={() => {
                    console.log("Navigate to recent products page")
                    setShowRecentProducts(false)
                  }}
                  className="w-full text-xs text-pink-500 hover:text-pink-600 font-medium transition-colors"
                >
                  전체 보기
                </button>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Navigation Buttons */}
      <div className="flex flex-col space-y-2">
        {/* Scroll to Top Button */}
        <AnimatePresence>
          {isVisible && (
            <motion.button
              onClick={scrollToTop}
              className="w-12 h-12 bg-white rounded-xl shadow-sm flex items-center justify-center hover:bg-gray-50 transition-colors border border-gray-200"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              transition={{ duration: 0.3 }}
              aria-label="맨 위로"
            >
              <ChevronUp className="w-5 h-5 text-gray-700" />
            </motion.button>
          )}
        </AnimatePresence>

        {/* Recent Products Button */}
        <motion.button
          onClick={toggleRecentProducts}
          className="w-12 h-12 bg-white rounded-xl shadow-sm flex items-center justify-center hover:bg-gray-50 transition-colors border border-gray-200 relative"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3, delay: 0.1 }}
          aria-label="최근 본 상품"
        >
          {recentProducts.length > 0 ? (
            <>
              <div className="w-8 h-8 rounded-lg overflow-hidden">
                <Image
                  src={recentProducts[0].image || "/placeholder.svg"}
                  alt="최근 본 상품"
                  width={32}
                  height={32}
                  className="w-full h-full object-cover"
                />
              </div>
              {recentProducts.length > 1 && (
                <div className="absolute -top-1 -right-1 w-5 h-5 bg-pink-500 text-white text-xs rounded-full flex items-center justify-center font-medium">
                  {recentProducts.length > 9 ? "9+" : recentProducts.length}
                </div>
              )}
            </>
          ) : (
            <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center">
              <span className="text-gray-400 text-xs">👀</span>
            </div>
          )}
        </motion.button>

        {/* KakaoTalk Button */}
        <motion.button
          onClick={handleKakaoChat}
          className="bg-yellow-300 hover:bg-yellow-400 w-12 h-12 rounded-xl flex items-center justify-center shadow-sm transition-colors"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3, delay: 0.2 }}
          aria-label="카카오 채팅"
        >
          <span className="text-lg font-bold text-gray-800">K</span>
        </motion.button>
      </div>
    </div>
  )
}
