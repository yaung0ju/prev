"use client"

import { useState, useRef, useEffect, useCallback, useMemo } from "react"
import { motion } from "framer-motion"
import ProductCard from "./product-card"
import { ChevronLeft, ChevronRight } from "lucide-react"

interface Product {
  id: number
  name: string
  brand: string
  price: number
  originalPrice?: number
  images?: string[]
  image?: string
  isLiked?: boolean
  category: string
  viewCount?: number
}

// Mock product data
const allMockProducts: Product[] = [
  {
    id: 1,
    name: "오버사이즈 울 니트 가디건 - 네이비",
    brand: "메종 키츠네",
    price: 249990,
    originalPrice: 350000,
    image: "/placeholder.svg?height=300&width=300&text=Product1",
    isLiked: false,
    category: "상의",
  },
  {
    id: 2,
    name: "4 스티치 슬림 2폴드 카드 홀더 - 블랙",
    brand: "메종 마르지엘라",
    price: 310990,
    originalPrice: 450000,
    image: "/placeholder.svg?height=300&width=300&text=Product2",
    isLiked: true,
    category: "지갑",
  },
  {
    id: 3,
    name: "카세트 클립형 머니클립 지갑 - 블랙",
    brand: "보테가베네타",
    price: 450990,
    originalPrice: 750000,
    image: "/placeholder.svg?height=300&width=300&text=Product3",
    isLiked: false,
    category: "지갑",
  },
  {
    id: 4,
    name: "마테라쎄 숄더백 - 블랙 / 5BP08...",
    brand: "미우미우",
    price: 1599990,
    originalPrice: 3200000,
    image: "/placeholder.svg?height=300&width=300&text=Product4",
    isLiked: false,
    category: "가방",
  },
  {
    id: 5,
    name: "클래식 토트백 - 블랙 / 5BG2312...",
    brand: "미우미우",
    price: 1986990,
    originalPrice: 2800000,
    image: "/placeholder.svg?height=300&width=300&text=Product5",
    isLiked: true,
    category: "가방",
  },
  {
    id: 6,
    name: "스몰 아이코닉 토트백 - 블랙 / 21...",
    brand: "페라가모",
    price: 1708990,
    originalPrice: 3500000,
    image: "/placeholder.svg?height=300&width=300&text=Product6",
    isLiked: false,
    category: "가방",
  },
  {
    id: 7,
    name: "미니 모노그램 볼테르 숄더백 - 블랙",
    brand: "생로랑",
    price: 2289990,
    originalPrice: 2900000,
    image: "/placeholder.svg?height=300&width=300&text=Product7",
    isLiked: false,
    category: "가방",
  },
  {
    id: 8,
    name: "오버사이즈 스니커즈 - 화이트",
    brand: "알렉산더 맥퀸",
    price: 650000,
    originalPrice: 800000,
    image: "/placeholder.svg?height=300&width=300&text=Product8",
    isLiked: false,
    category: "스니커즈",
  },
  {
    id: 9,
    name: "트리플 S 스니커즈 - 블랙",
    brand: "발렌시아가",
    price: 980000,
    originalPrice: 1200000,
    image: "/placeholder.svg?height=300&width=300&text=Product9",
    isLiked: true,
    category: "스니커즈",
  },
  {
    id: 10,
    name: "로고 프린트 티셔츠 - 화이트",
    brand: "구찌",
    price: 520000,
    originalPrice: 600000,
    image: "/placeholder.svg?height=300&width=300&text=Product10",
    isLiked: false,
    category: "상의",
  },
  {
    id: 11,
    name: "슬림핏 데님 팬츠 - 블루",
    brand: "디젤",
    price: 180000,
    originalPrice: 220000,
    image: "/placeholder.svg?height=300&width=300&text=Product11",
    isLiked: false,
    category: "하의",
  },
  {
    id: 12,
    name: "퀼팅 재킷 - 블랙",
    brand: "몽클레어",
    price: 1500000,
    originalPrice: 1800000,
    image: "/placeholder.svg?height=300&width=300&text=Product12",
    isLiked: false,
    category: "아우터",
  },
  {
    id: 13,
    name: "클래식 로퍼 - 브라운",
    brand: "페라가모",
    price: 700000,
    originalPrice: 850000,
    image: "/placeholder.svg?height=300&width=300&text=Product13",
    isLiked: false,
    category: "슈즈",
  },
  {
    id: 14,
    name: "미니 체인 백 - 레드",
    brand: "샤넬",
    price: 5000000,
    originalPrice: 6000000,
    image: "/placeholder.svg?height=300&width=300&text=Product14",
    isLiked: false,
    category: "가방",
  },
  {
    id: 15,
    name: "로고 엠브로이더리 후드티 - 그레이",
    brand: "아미",
    price: 400000,
    originalPrice: 480000,
    image: "/placeholder.svg?height=300&width=300&text=Product15",
    isLiked: false,
    category: "상의",
  },
  {
    id: 16,
    name: "와이드 팬츠 - 베이지",
    brand: "마르니",
    price: 600000,
    originalPrice: 700000,
    image: "/placeholder.svg?height=300&width=300&text=Product16",
    isLiked: false,
    category: "하의",
  },
  {
    id: 17,
    name: "트렌치 코트 - 베이지",
    brand: "버버리",
    price: 2500000,
    originalPrice: 3000000,
    image: "/placeholder.svg?height=300&width=300&text=Product17",
    isLiked: false,
    category: "아우터",
  },
  {
    id: 18,
    name: "첼시 부츠 - 블랙",
    brand: "생로랑",
    price: 1100000,
    originalPrice: 1300000,
    image: "/placeholder.svg?height=300&width=300&text=Product18",
    isLiked: false,
    category: "슈즈",
  },
  {
    id: 19,
    name: "카드 지갑 - 브라운",
    brand: "루이비통",
    price: 550000,
    originalPrice: 650000,
    image: "/placeholder.svg?height=300&width=300&text=Product19",
    isLiked: false,
    category: "지갑",
  },
  {
    id: 20,
    name: "크로스백 - 블랙",
    brand: "셀린느",
    price: 2800000,
    originalPrice: 3200000,
    image: "/placeholder.svg?height=300&width=300&text=Product20",
    isLiked: false,
    category: "가방",
  },
  {
    id: 21,
    name: "캐시미어 스웨터 - 아이보리",
    brand: "프라다",
    price: 1200000,
    originalPrice: 1400000,
    image: "/placeholder.svg?height=300&width=300&text=Product21",
    isLiked: false,
    category: "상의",
  },
  {
    id: 22,
    name: "슬랙스 - 블랙",
    brand: "지방시",
    price: 700000,
    originalPrice: 800000,
    image: "/placeholder.svg?height=300&width=300&text=Product22",
    isLiked: false,
    category: "하의",
  },
  {
    id: 23,
    name: "패딩 베스트 - 네이비",
    brand: "오프화이트",
    price: 900000,
    originalPrice: 1100000,
    image: "/placeholder.svg?height=300&width=300&text=Product23",
    isLiked: false,
    category: "아우터",
  },
  {
    id: 24,
    name: "스니커즈 - 화이트/블랙",
    brand: "릭오웬스",
    price: 850000,
    originalPrice: 1000000,
    image: "/placeholder.svg?height=300&width=300&text=Product24",
    isLiked: false,
    category: "스니커즈",
  },
  {
    id: 25,
    name: "클러치 백 - 블랙",
    brand: "보테가베네타",
    price: 1800000,
    originalPrice: 2200000,
    image: "/placeholder.svg?height=300&width=300&text=Product25",
    isLiked: false,
    category: "가방",
  },
  {
    id: 26,
    name: "로고 티셔츠 - 블랙",
    brand: "발렌티노",
    price: 450000,
    originalPrice: 550000,
    image: "/placeholder.svg?height=300&width=300&text=Product26",
    isLiked: false,
    category: "상의",
  },
  {
    id: 27,
    name: "스키니 진 - 블랙",
    brand: "아크네 스튜디오",
    price: 300000,
    originalPrice: 380000,
    image: "/placeholder.svg?height=300&width=300&text=Product27",
    isLiked: false,
    category: "하의",
  },
  {
    id: 28,
    name: "봄버 재킷 - 카키",
    brand: "베르사체",
    price: 1300000,
    originalPrice: 1600000,
    image: "/placeholder.svg?height=300&width=300&text=Product28",
    isLiked: false,
    category: "아우터",
  },
  {
    id: 29,
    name: "스니커즈 - 그레이",
    brand: "디올",
    price: 900000,
    originalPrice: 1100000,
    image: "/placeholder.svg?height=300&width=300&text=Product29",
    isLiked: false,
    category: "스니커즈",
  },
  {
    id: 30,
    name: "지갑 - 핑크",
    brand: "티파니",
    price: 700000,
    originalPrice: 800000,
    image: "/placeholder.svg?height=300&width=300&text=Product30",
    isLiked: false,
    category: "지갑",
  },
]

export default function RankingAndRecommendationSection() {
  const mainTabs = ["실시간 랭킹", "내 취향 맞춤 추천", "나를 위한 추천"]
  const categoryTabs = ["전체", "지갑", "스니커즈", "가방", "상의", "하의", "아우터", "슈즈"]

  const [activeMainTab, setActiveMainTab] = useState(mainTabs[0])
  const [activeCategoryTab, setActiveCategoryTab] = useState(categoryTabs[0])
  const [currentSlide, setCurrentSlide] = useState(0)
  const sliderRef = useRef<HTMLDivElement>(null)

  // Filter and sort products based on active tabs
  const filteredProducts = useMemo(() => {
    let products = allMockProducts

    if (activeMainTab === "실시간 랭킹") {
      if (activeCategoryTab !== "전체") {
        products = products.filter((p) => p.category === activeCategoryTab)
      }
      // Sort by viewCount or a similar ranking metric if available, otherwise by discount
      return products.sort((a, b) => (b.viewCount || 0) - (a.viewCount || 0)).slice(0, 30)
    } else if (activeMainTab === "내 취향 맞춤 추천") {
      // Placeholder for personalized recommendations
      return products.filter((p) => p.isLiked).slice(0, 30)
    } else if (activeMainTab === "나를 위한 추천") {
      // Placeholder for general recommendations
      return products.sort(() => 0.5 - Math.random()).slice(0, 30)
    }
    return products.slice(0, 30)
  }, [activeMainTab, activeCategoryTab])

  // Calculate items per slide for 3x2 grid (6 items per slide)
  const itemsPerSlide = 6
  const totalSlides = Math.ceil(filteredProducts.length / itemsPerSlide)

  const goToSlide = useCallback(
    (index: number) => {
      setCurrentSlide(index)
      if (sliderRef.current) {
        const slideWidth = sliderRef.current.clientWidth // Get the full width of the slider container
        sliderRef.current.scrollTo({
          left: index * slideWidth,
          behavior: "smooth",
        })
      }
    },
    [itemsPerSlide],
  )

  const nextSlide = useCallback(() => {
    goToSlide((currentSlide + 1) % totalSlides)
  }, [currentSlide, totalSlides, goToSlide])

  const prevSlide = useCallback(() => {
    goToSlide((currentSlide - 1 + totalSlides) % totalSlides)
  }, [currentSlide, totalSlides, goToSlide])

  // Reset slide when tabs change
  useEffect(() => {
    setCurrentSlide(0)
    if (sliderRef.current) {
      sliderRef.current.scrollTo({ left: 0, behavior: "smooth" })
    }
  }, [activeMainTab, activeCategoryTab])

  return (
    <section className="bg-gray-50 py-8 md:py-12">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        {/* Main Tabs */}
        <div className="flex justify-between items-center mb-6 overflow-x-auto scrollbar-hide">
          <div className="flex space-x-2 md:space-x-4 min-w-max">
            {mainTabs.map((tab) => (
              <button
                key={tab}
                className={`px-4 py-2 md:px-6 md:py-3 text-sm md:text-base font-semibold rounded-full transition-colors whitespace-nowrap
                  ${
                    activeMainTab === tab
                      ? "bg-gray-900 text-white shadow-md"
                      : "bg-white text-gray-700 hover:bg-gray-100 border border-gray-200"
                  }`}
                onClick={() => {
                  setActiveMainTab(tab)
                  setActiveCategoryTab("전체") // Reset category tab when main tab changes
                }}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Section Title for "실시간 랭킹" */}
        {activeMainTab === "실시간 랭킹" && (
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-6">실시간 랭킹</h2>
        )}

        {/* Category Tabs (only for "실시간 랭킹") */}
        {activeMainTab === "실시간 랭킹" && (
          <div className="flex justify-between items-center mb-6 overflow-x-auto scrollbar-hide">
            <div className="flex space-x-2 md:space-x-3 min-w-max">
              {categoryTabs.map((tab) => (
                <button
                  key={tab}
                  className={`px-3 py-1.5 md:px-4 md:py-2 text-xs md:text-sm rounded-full transition-colors whitespace-nowrap
                    ${
                      activeCategoryTab === tab
                        ? "bg-white text-gray-900 border-2 border-gray-900 font-medium"
                        : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                    }`}
                  onClick={() => setActiveCategoryTab(tab)}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Product Slider */}
        <motion.div
          className="relative"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <div
            ref={sliderRef}
            className="flex overflow-x-scroll snap-x snap-mandatory scrollbar-hide"
            style={{ scrollSnapType: "x mandatory" }}
          >
            {Array.from({ length: totalSlides }).map((_, slideIndex) => (
              <div
                key={slideIndex}
                className="flex-shrink-0 w-full snap-center grid grid-cols-3 grid-rows-2 gap-x-4 gap-y-6 p-2" // 3x2 grid
                style={{
                  minWidth: "100%", // Ensure each slide takes full width
                  scrollSnapAlign: "start",
                }}
              >
                {filteredProducts.slice(slideIndex * itemsPerSlide, (slideIndex + 1) * itemsPerSlide).map((product) => (
                  <ProductCard key={product.id} {...product} showImageNavigation={true} />
                ))}
              </div>
            ))}
          </div>

          {/* Navigation buttons - only show if more than 1 slide */}
          {totalSlides > 1 && (
            <>
              <motion.button
                onClick={prevSlide}
                className="absolute left-0 top-1/2 -translate-y-1/2 w-10 h-10 bg-white shadow-lg rounded-full flex items-center justify-center hover:bg-gray-50 transition-all duration-300 z-10 -ml-5"
                initial={{ opacity: 0.3 }}
                whileHover={{ opacity: 1 }}
                whileTap={{ opacity: 1 }}
              >
                <ChevronLeft className="w-5 h-5 text-gray-600" />
              </motion.button>
              <motion.button
                onClick={nextSlide}
                className="absolute right-0 top-1/2 -translate-y-1/2 w-10 h-10 bg-white shadow-lg rounded-full flex items-center justify-center hover:bg-gray-50 transition-all duration-300 z-10 -mr-5"
                initial={{ opacity: 0.3 }}
                whileHover={{ opacity: 1 }}
                whileTap={{ opacity: 1 }}
              >
                <ChevronRight className="w-5 h-5 text-gray-600" />
              </motion.button>
            </>
          )}

          {/* Pagination Dots - only show if more than 1 slide */}
          {totalSlides > 1 && (
            <div className="flex justify-center mt-4 space-x-2">
              {Array.from({ length: totalSlides }).map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToSlide(index)}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    index === currentSlide ? "bg-gray-800 scale-125" : "bg-gray-300 hover:bg-gray-500"
                  }`}
                  aria-label={`슬라이드 ${index + 1}로 이동`}
                />
              ))}
            </div>
          )}
        </motion.div>
      </div>
    </section>
  )
}
