"use client"

import { motion } from "framer-motion"
import { ShoppingBag, Gem, Watch, Shirt, Users, Baby, Home, MessageCircle } from "lucide-react"

const recommendedCategories = [
  {
    id: "bag",
    name: "가방",
    icon: ShoppingBag,
    description: "럭셔리 핸드백 & 지갑",
    count: 245,
    color: "bg-pink-100 text-pink-600 hover:bg-pink-200",
  },
  {
    id: "jewelry",
    name: "주얼리",
    icon: Gem,
    description: "프리미엄 액세서리",
    count: 189,
    color: "bg-purple-100 text-purple-600 hover:bg-purple-200",
  },
  {
    id: "watch",
    name: "시계",
    icon: Watch,
    description: "명품 타임피스",
    count: 156,
    color: "bg-blue-100 text-blue-600 hover:bg-blue-200",
  },
  {
    id: "women-fashion",
    name: "여성패션",
    icon: Shirt,
    description: "트렌디한 여성 의류",
    count: 234,
    color: "bg-rose-100 text-rose-600 hover:bg-rose-200",
  },
  {
    id: "men-fashion",
    name: "남성패션",
    icon: Users,
    description: "세련된 남성 스타일",
    count: 123,
    color: "bg-gray-100 text-gray-600 hover:bg-gray-200",
  },
  {
    id: "kids",
    name: "키즈",
    icon: Baby,
    description: "아이들을 위한 특별함",
    count: 89,
    color: "bg-yellow-100 text-yellow-600 hover:bg-yellow-200",
  },
  {
    id: "home",
    name: "메종",
    icon: Home,
    description: "럭셔리 홈 & 리빙",
    count: 67,
    color: "bg-green-100 text-green-600 hover:bg-green-200",
  },
  {
    id: "community",
    name: "커뮤니티",
    icon: MessageCircle,
    description: "소통과 정보 공유",
    count: 45,
    color: "bg-indigo-100 text-indigo-600 hover:bg-indigo-200",
  },
]

export default function RecommendedCategoriesSection() {
  const handleCategoryClick = (categoryId: string) => {
    console.log(`Navigate to category: ${categoryId}`)
  }

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">추천 카테고리</h2>
          <p className="text-gray-600">원하는 카테고리를 한눈에 탐색해보세요</p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {recommendedCategories.map((category, index) => {
            const Icon = category.icon
            return (
              <motion.button
                key={category.id}
                className={`p-6 rounded-2xl transition-all duration-300 text-left group hover:shadow-lg hover:scale-105 ${category.color}`}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -5 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => handleCategoryClick(category.id)}
              >
                <div className="flex flex-col items-center text-center space-y-3">
                  <div className="w-16 h-16 bg-white bg-opacity-50 rounded-full flex items-center justify-center group-hover:bg-opacity-75 transition-all duration-300">
                    <Icon className="w-8 h-8" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg mb-1">{category.name}</h3>
                    <p className="text-sm opacity-75 mb-2">{category.description}</p>
                    <span className="text-xs font-medium opacity-60">{category.count}개 상품</span>
                  </div>
                </div>
              </motion.button>
            )
          })}
        </div>

        {/* View All Button */}
        <motion.div
          className="text-center mt-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <button className="px-8 py-3 bg-gray-900 text-white rounded-full hover:bg-gray-800 transition-colors font-medium">
            모든 카테고리 보기
          </button>
        </motion.div>
      </div>
    </section>
  )
}
