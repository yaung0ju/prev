"use client"

import { useEffect, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronRight, Star } from "lucide-react"
import Image from "next/image"

interface SubCategory {
  id: string
  name: string
  count?: number
  image?: string
}

interface CategoryData {
  id: string
  name: string
  subcategories: SubCategory[]
  popularBrands: {
    id: number
    name: string
    nameEN: string
    image: string
  }[]
  featuredImage?: string
}

const categoryMegaData: { [key: string]: CategoryData } = {
  가방: {
    id: "bag",
    name: "가방",
    subcategories: [
      { id: "tote", name: "토트백", count: 245, image: "/placeholder.svg?height=120&width=120" },
      { id: "crossbody", name: "크로스백", count: 189, image: "/placeholder.svg?height=120&width=120" },
      { id: "shoulder", name: "숄더백", count: 167, image: "/placeholder.svg?height=120&width=120" },
      { id: "hobo", name: "호보백", count: 156, image: "/placeholder.svg?height=120&width=120" },
      { id: "bucket", name: "버킷백", count: 134, image: "/placeholder.svg?height=120&width=120" },
      { id: "mini", name: "미니백", count: 123, image: "/placeholder.svg?height=120&width=120" },
      { id: "backpack", name: "백팩", count: 98, image: "/placeholder.svg?height=120&width=120" },
      { id: "clutch", name: "클러치", count: 87, image: "/placeholder.svg?height=120&width=120" },
      { id: "wallet", name: "지갑", count: 167, image: "/placeholder.svg?height=120&width=120" },
    ],
    popularBrands: [
      { id: 1, name: "샤넬", nameEN: "CHANEL", image: "/placeholder.svg?height=40&width=40" },
      { id: 2, name: "루이비통", nameEN: "LOUIS VUITTON", image: "/placeholder.svg?height=40&width=40" },
      { id: 3, name: "에르메스", nameEN: "HERMÈS", image: "/placeholder.svg?height=40&width=40" },
      { id: 4, name: "구찌", nameEN: "GUCCI", image: "/placeholder.svg?height=40&width=40" },
      { id: 5, name: "프라다", nameEN: "PRADA", image: "/placeholder.svg?height=40&width=40" },
      { id: 6, name: "셀린느", nameEN: "CELINE", image: "/placeholder.svg?height=40&width=40" },
    ],
    featuredImage: "/placeholder.svg?height=200&width=300",
  },
  주얼리: {
    id: "jewelry",
    name: "주얼리",
    subcategories: [
      { id: "ring", name: "반지", count: 312, image: "/placeholder.svg?height=120&width=120" },
      { id: "earring", name: "귀걸이", count: 278, image: "/placeholder.svg?height=120&width=120" },
      { id: "necklace", name: "목걸이", count: 245, image: "/placeholder.svg?height=120&width=120" },
      { id: "bracelet", name: "팔찌", count: 189, image: "/placeholder.svg?height=120&width=120" },
      { id: "brooch", name: "브로치", count: 45, image: "/placeholder.svg?height=120&width=120" },
      { id: "pendant", name: "펜던트", count: 123, image: "/placeholder.svg?height=120&width=120" },
    ],
    popularBrands: [
      { id: 7, name: "티파니", nameEN: "TIFFANY & CO.", image: "/placeholder.svg?height=40&width=40" },
      { id: 8, name: "까르띠에", nameEN: "CARTIER", image: "/placeholder.svg?height=40&width=40" },
      { id: 9, name: "불가리", nameEN: "BULGARI", image: "/placeholder.svg?height=40&width=40" },
      { id: 10, name: "반클리프", nameEN: "VAN CLEEF & ARPELS", image: "/placeholder.svg?height=40&width=40" },
    ],
    featuredImage: "/placeholder.svg?height=200&width=300",
  },
  시계: {
    id: "watch",
    name: "시계",
    subcategories: [
      { id: "women-watch", name: "여성시계", count: 189, image: "/placeholder.svg?height=120&width=120" },
      { id: "men-watch", name: "남성시계", count: 156, image: "/placeholder.svg?height=120&width=120" },
      { id: "luxury-watch", name: "럭셔리시계", count: 134, image: "/placeholder.svg?height=120&width=120" },
      { id: "smart-watch", name: "스마트워치", count: 98, image: "/placeholder.svg?height=120&width=120" },
    ],
    popularBrands: [
      { id: 11, name: "롤렉스", nameEN: "ROLEX", image: "/placeholder.svg?height=40&width=40" },
      { id: 12, name: "오메가", nameEN: "OMEGA", image: "/placeholder.svg?height=40&width=40" },
      { id: 13, name: "까르띠에", nameEN: "CARTIER", image: "/placeholder.svg?height=40&width=40" },
      { id: 14, name: "파텍필립", nameEN: "PATEK PHILIPPE", image: "/placeholder.svg?height=40&width=40" },
    ],
    featuredImage: "/placeholder.svg?height=200&width=300",
  },
  여성패션: {
    id: "women-fashion",
    name: "여성패션",
    subcategories: [
      { id: "dress", name: "드레스", count: 234, image: "/placeholder.svg?height=120&width=120" },
      { id: "top", name: "상의", count: 189, image: "/placeholder.svg?height=120&width=120" },
      { id: "bottom", name: "하의", count: 167, image: "/placeholder.svg?height=120&width=120" },
      { id: "outerwear", name: "아우터", count: 145, image: "/placeholder.svg?height=120&width=120" },
      { id: "shoes", name: "신발", count: 123, image: "/placeholder.svg?height=120&width=120" },
      { id: "accessories", name: "액세서리", count: 98, image: "/placeholder.svg?height=120&width=120" },
    ],
    popularBrands: [
      { id: 15, name: "샤넬", nameEN: "CHANEL", image: "/placeholder.svg?height=40&width=40" },
      { id: 16, name: "디올", nameEN: "DIOR", image: "/placeholder.svg?height=40&width=40" },
      { id: 17, name: "생로랑", nameEN: "SAINT LAURENT", image: "/placeholder.svg?height=40&width=40" },
      { id: 18, name: "발렌시아가", nameEN: "BALENCIAGA", image: "/placeholder.svg?height=40&width=40" },
    ],
    featuredImage: "/placeholder.svg?height=200&width=300",
  },
  남성패션: {
    id: "men-fashion",
    name: "남성패션",
    subcategories: [
      { id: "suit", name: "정장", count: 123, image: "/placeholder.svg?height=120&width=120" },
      { id: "casual", name: "캐주얼", count: 98, image: "/placeholder.svg?height=120&width=120" },
      { id: "shoes", name: "신발", count: 87, image: "/placeholder.svg?height=120&width=120" },
      { id: "accessories", name: "액세서리", count: 76, image: "/placeholder.svg?height=120&width=120" },
    ],
    popularBrands: [
      { id: 19, name: "톰포드", nameEN: "TOM FORD", image: "/placeholder.svg?height=40&width=40" },
      { id: 20, name: "구찌", nameEN: "GUCCI", image: "/placeholder.svg?height=40&width=40" },
      { id: 21, name: "발렌시아가", nameEN: "BALENCIAGA", image: "/placeholder.svg?height=40&width=40" },
    ],
    featuredImage: "/placeholder.svg?height=200&width=300",
  },
  오뜨펫: {
    id: "haute-pet",
    name: "오뜨펫",
    subcategories: [
      { id: "pet-clothes", name: "펫의류", count: 45, image: "/placeholder.svg?height=120&width=120" },
      { id: "pet-accessories", name: "펫액세서리", count: 67, image: "/placeholder.svg?height=120&width=120" },
      { id: "pet-toys", name: "펫토이", count: 34, image: "/placeholder.svg?height=120&width=120" },
    ],
    popularBrands: [
      { id: 22, name: "루이비통", nameEN: "LOUIS VUITTON", image: "/placeholder.svg?height=40&width=40" },
      { id: 23, name: "구찌", nameEN: "GUCCI", image: "/placeholder.svg?height=40&width=40" },
    ],
    featuredImage: "/placeholder.svg?height=200&width=300",
  },
  키즈: {
    id: "kids",
    name: "키즈",
    subcategories: [
      { id: "kids-clothes", name: "키즈의류", count: 89, image: "/placeholder.svg?height=120&width=120" },
      { id: "baby-goods", name: "육아용품", count: 123, image: "/placeholder.svg?height=120&width=120" },
      { id: "toys", name: "장난감", count: 67, image: "/placeholder.svg?height=120&width=120" },
    ],
    popularBrands: [
      { id: 24, name: "버버리", nameEN: "BURBERRY", image: "/placeholder.svg?height=40&width=40" },
      { id: 25, name: "몽클레어", nameEN: "MONCLER", image: "/placeholder.svg?height=40&width=40" },
    ],
    featuredImage: "/placeholder.svg?height=200&width=300",
  },
  메종: {
    id: "maison",
    name: "메종",
    subcategories: [
      { id: "tableware", name: "테이블웨어", count: 67, image: "/placeholder.svg?height=120&width=120" },
      { id: "home-decor", name: "홈데코", count: 89, image: "/placeholder.svg?height=120&width=120" },
      { id: "furniture", name: "가구", count: 45, image: "/placeholder.svg?height=120&width=120" },
    ],
    popularBrands: [
      { id: 26, name: "에르메스", nameEN: "HERMÈS", image: "/placeholder.svg?height=40&width=40" },
      { id: 27, name: "루이비통", nameEN: "LOUIS VUITTON", image: "/placeholder.svg?height=40&width=40" },
    ],
    featuredImage: "/placeholder.svg?height=200&width=300",
  },
  커뮤니티: {
    id: "community",
    name: "커뮤니티",
    subcategories: [
      { id: "process", name: "제작공정", count: 12, image: "/placeholder.svg?height=120&width=120" },
      { id: "notice", name: "공지사항", count: 8, image: "/placeholder.svg?height=120&width=120" },
      { id: "review", name: "리뷰", count: 156, image: "/placeholder.svg?height=120&width=120" },
    ],
    popularBrands: [],
    featuredImage: "/placeholder.svg?height=200&width=300",
  },
}

interface CategoryMegaPanelProps {
  isOpen: boolean
  activeCategory: string | null
  onClose: () => void
  onCategoryClick?: (categoryId: string) => void
  onSubcategoryClick?: (categoryId: string, subcategoryId: string) => void
  onBrandClick?: (brandId: number) => void
}

export default function CategoryMegaPanel({
  isOpen,
  activeCategory,
  onClose,
  onCategoryClick,
  onSubcategoryClick,
  onBrandClick,
}: CategoryMegaPanelProps) {
  const panelRef = useRef<HTMLDivElement>(null)

  // Close panel when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (panelRef.current && !panelRef.current.contains(event.target as Node)) {
        onClose()
      }
    }

    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside)
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [isOpen, onClose])

  const categoryData = activeCategory ? categoryMegaData[activeCategory] : null

  if (!categoryData) return null

  const handleSubcategoryClick = (subcategoryId: string) => {
    onSubcategoryClick?.(categoryData.id, subcategoryId)
    onClose()
  }

  const handleBrandClick = (brandId: number) => {
    onBrandClick?.(brandId)
    onClose()
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          ref={panelRef}
          className="absolute left-0 right-0 top-full bg-white shadow-xl border-t border-gray-200 z-50 max-h-[70vh] overflow-y-auto"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
        >
          <div className="max-w-7xl mx-auto p-8">
            <div className="grid grid-cols-12 gap-8">
              {/* Subcategories */}
              <div className="col-span-8">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-gray-900">{categoryData.name}</h3>
                  <button
                    onClick={() => onCategoryClick?.(categoryData.id)}
                    className="text-sm text-pink-500 hover:text-pink-600 font-medium flex items-center space-x-1"
                  >
                    <span>전체보기</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-3 gap-6">
                  {categoryData.subcategories.map((subcategory, index) => (
                    <motion.button
                      key={subcategory.id}
                      className="group text-left p-4 rounded-lg hover:bg-gray-50 transition-colors"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                      onClick={() => handleSubcategoryClick(subcategory.id)}
                    >
                      <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden mb-3">
                        <Image
                          src={subcategory.image || "/placeholder.svg"}
                          alt={subcategory.name}
                          width={120}
                          height={120}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                      <h4 className="font-medium text-gray-900 group-hover:text-pink-600 transition-colors">
                        {subcategory.name}
                      </h4>
                      {subcategory.count && <p className="text-sm text-gray-500 mt-1">{subcategory.count}개 상품</p>}
                    </motion.button>
                  ))}
                </div>
              </div>

              {/* Featured & Popular Brands */}
              <div className="col-span-4 space-y-6">
                {/* Featured Image */}
                {categoryData.featuredImage && (
                  <div className="aspect-[3/2] bg-gray-100 rounded-lg overflow-hidden">
                    <Image
                      src={categoryData.featuredImage || "/placeholder.svg"}
                      alt={`${categoryData.name} featured`}
                      width={300}
                      height={200}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}

                {/* Popular Brands */}
                {categoryData.popularBrands.length > 0 && (
                  <div>
                    <div className="flex items-center space-x-2 mb-4">
                      <Star className="w-4 h-4 text-pink-500" />
                      <h4 className="font-medium text-gray-900">인기 브랜드</h4>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      {categoryData.popularBrands.map((brand, index) => (
                        <motion.button
                          key={brand.id}
                          className="p-3 bg-gray-50 hover:bg-pink-50 rounded-lg transition-colors text-left group"
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ duration: 0.3, delay: index * 0.1 }}
                          onClick={() => handleBrandClick(brand.id)}
                        >
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-white rounded-lg overflow-hidden flex-shrink-0">
                              <Image
                                src={brand.image || "/placeholder.svg"}
                                alt={brand.name}
                                width={40}
                                height={40}
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <div className="min-w-0 flex-1">
                              <p className="text-sm font-medium text-gray-900 group-hover:text-pink-600 transition-colors truncate">
                                {brand.name}
                              </p>
                              <p className="text-xs text-gray-500 truncate">{brand.nameEN}</p>
                            </div>
                          </div>
                        </motion.button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
