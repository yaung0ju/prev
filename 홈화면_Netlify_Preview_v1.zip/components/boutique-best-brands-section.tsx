"use client"

import { useState, useRef, useCallback } from "react"
import { motion } from "framer-motion"
import Image from "next/image"
import ProductCard from "./product-card"
import { ChevronLeft, ChevronRight } from "lucide-react"

interface Product {
  id: number
  name: string
  brand: string
  price: number
  originalPrice?: number
  images?: string[]
  image?: string
  isLiked?: boolean
  category: string
  viewCount?: number
}

interface BrandProductSet {
  brandId: string
  brandName: string
  bannerImage: string
  products: Product[]
  seeMoreLink: string // Add seeMoreLink for each brand set
}

const mockBrandProductSets: BrandProductSet[] = [
  {
    brandId: "diesel",
    brandName: "디젤",
    bannerImage: "/placeholder.svg?height=300&width=600&text=부티크+BEST+BRAND+디젤",
    products: [
      {
        id: 101,
        name: "1995 D 사르크 데님 팬츠 - 라이트 블루",
        brand: "디젤",
        price: 132990,
        originalPrice: 332475,
        image: "/placeholder.svg?height=300&width=300&text=DieselProduct1",
        isLiked: false,
        category: "하의",
      },
      {
        id: 102,
        name: "SA 오발 D PF W 샌들 - 블루",
        brand: "디젤",
        price: 252990,
        originalPrice: 361414,
        image: "/placeholder.svg?height=300&width=300&text=DieselProduct2",
        isLiked: true,
        category: "슈즈",
      },
      {
        id: 103,
        name: "1DR XS 숄더백 - 블랙 / X08...",
        brand: "디젤",
        price: 284990,
        originalPrice: 712475,
        image: "/placeholder.svg?height=300&width=300&text=DieselProduct3",
        isLiked: false,
        category: "가방",
      },
    ],
    seeMoreLink: "/brand/diesel", // Example link
  },
  {
    brandId: "saint-laurent",
    brandName: "생로랑",
    bannerImage: "/placeholder.svg?height=300&width=600&text=부티크+BEST+BRAND+생로랑",
    products: [
      {
        id: 104,
        name: "미니 모노그램 볼테르 숄더백 - 블랙",
        brand: "생로랑",
        price: 2289990,
        originalPrice: 2900000,
        image: "/placeholder.svg?height=300&width=300&text=SaintLaurentProduct1",
        isLiked: false,
        category: "가방",
      },
      {
        id: 105,
        name: "카산드라 플랩 지갑 - 블랙",
        brand: "생로랑",
        price: 750000,
        originalPrice: 900000,
        image: "/placeholder.svg?height=300&width=300&text=SaintLaurentProduct2",
        isLiked: true,
        category: "지갑",
      },
      {
        id: 106,
        name: "로고 프린트 티셔츠 - 화이트",
        brand: "생로랑",
        price: 450000,
        originalPrice: 550000,
        image: "/placeholder.svg?height=300&width=300&text=SaintLaurentProduct3",
        isLiked: false,
        category: "상의",
      },
    ],
    seeMoreLink: "/brand/saint-laurent", // Example link
  },
  {
    brandId: "balenciaga",
    brandName: "발렌시아가",
    bannerImage: "/placeholder.svg?height=300&width=600&text=부티크+BEST+BRAND+발렌시아가",
    products: [
      {
        id: 107,
        name: "트리플 S 스니커즈 - 그레이",
        brand: "발렌시아가",
        price: 980000,
        originalPrice: 1200000,
        image: "/placeholder.svg?height=300&width=300&text=BalenciagaProduct1",
        isLiked: false,
        category: "슈즈",
      },
      {
        id: 108,
        name: "아워글래스 미니 백 - 블랙",
        brand: "발렌시아가",
        price: 1800000,
        originalPrice: 2200000,
        image: "/placeholder.svg?height=300&width=300&text=BalenciagaProduct2",
        isLiked: true,
        category: "가방",
      },
      {
        id: 109,
        name: "로고 후드티 - 블랙",
        brand: "발렌시아가",
        price: 700000,
        originalPrice: 850000,
        image: "/placeholder.svg?height=300&width=300&text=BalenciagaProduct3",
        isLiked: false,
        category: "상의",
      },
    ],
    seeMoreLink: "/brand/balenciaga", // Example link
  },
]

export default function BoutiqueBestBrandsSection() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const sliderRef = useRef<HTMLDivElement>(null)

  const totalSlides = mockBrandProductSets.length

  const goToSlide = useCallback((index: number) => {
    setCurrentSlide(index)
    if (sliderRef.current) {
      const slideWidth = sliderRef.current.clientWidth
      sliderRef.current.scrollTo({
        left: index * slideWidth,
        behavior: "smooth",
      })
    }
  }, [])

  const nextSlide = useCallback(() => {
    goToSlide((currentSlide + 1) % totalSlides)
  }, [currentSlide, totalSlides, goToSlide])

  const prevSlide = useCallback(() => {
    goToSlide((currentSlide - 1 + totalSlides) % totalSlides)
  }, [currentSlide, totalSlides, goToSlide])

  return (
    <section className="bg-white py-8 md:py-12">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-6">부티크 베스트 브랜드</h2>

        <motion.div
          className="relative"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <div
            ref={sliderRef}
            className="flex overflow-x-scroll snap-x snap-mandatory scrollbar-hide"
            style={{ scrollSnapType: "x mandatory" }}
          >
            {mockBrandProductSets.map((brandSet, slideIndex) => (
              <div key={brandSet.brandId} className="flex-shrink-0 w-full snap-center p-2" style={{ minWidth: "100%" }}>
                {/* Brand Banner */}
                <div className="relative w-full h-[180px] md:h-[250px] rounded-lg overflow-hidden mb-4">
                  <Image
                    src={brandSet.bannerImage || "/placeholder.svg"}
                    alt={`${brandSet.brandName} Banner`}
                    layout="fill"
                    objectFit="cover"
                    className="brightness-75"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent p-4 flex flex-col justify-end">
                    <h3 className="text-white text-xl md:text-2xl font-bold mb-1">부티크 BEST BRAND</h3>
                    <span className="text-white text-lg md:text-xl font-semibold">{brandSet.brandName}</span>
                  </div>
                </div>

                {/* Brand Products (3 columns) and See More Button */}
                <div className="grid grid-cols-3 gap-x-4 gap-y-6">
                  {brandSet.products.map((product) => (
                    <ProductCard key={product.id} {...product} showImageNavigation={true} />
                  ))}
                  {/* "더보기" button as the last item in the grid */}
                  <div className="flex items-center justify-center">
                    <a
                      href={brandSet.seeMoreLink}
                      className="bg-gray-900 text-white px-6 py-3 rounded-full text-sm font-medium hover:bg-gray-700 transition-colors shadow-md whitespace-nowrap"
                    >
                      더보기
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Navigation buttons - only show if more than 1 slide */}
          {totalSlides > 1 && (
            <>
              <motion.button
                onClick={prevSlide}
                className="absolute left-0 top-1/2 -translate-y-1/2 w-10 h-10 bg-white shadow-lg rounded-full flex items-center justify-center hover:bg-gray-50 transition-all duration-300 z-10 -ml-5"
                initial={{ opacity: 0.3 }}
                whileHover={{ opacity: 1 }}
                whileTap={{ opacity: 1 }}
              >
                <ChevronLeft className="w-5 h-5 text-gray-600" />
              </motion.button>
              <motion.button
                onClick={nextSlide}
                className="absolute right-0 top-1/2 -translate-y-1/2 w-10 h-10 bg-white shadow-lg rounded-full flex items-center justify-center hover:bg-gray-50 transition-all duration-300 z-10 -mr-5"
                initial={{ opacity: 0.3 }}
                whileHover={{ opacity: 1 }}
                whileTap={{ opacity: 1 }}
              >
                <ChevronRight className="w-5 h-5 text-gray-600" />
              </motion.button>
            </>
          )}

          {/* Pagination Dots - only show if more than 1 slide */}
          {totalSlides > 1 && (
            <div className="flex justify-center mt-4 space-x-2">
              {Array.from({ length: totalSlides }).map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToSlide(index)}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    index === currentSlide ? "bg-gray-800 scale-125" : "bg-gray-300 hover:bg-gray-500"
                  }`}
                  aria-label={`슬라이드 ${index + 1}로 이동`}
                />
              ))}
            </div>
          )}
        </motion.div>
      </div>
    </section>
  )
}
