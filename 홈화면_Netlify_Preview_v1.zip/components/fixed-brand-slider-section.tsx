"use client"

import { useState, useRef } from "react"
import { motion } from "framer-motion"
import Image from "next/image"
import { ChevronLeft, ChevronRight } from "lucide-react"
import ProductCard from "./product-card"

interface Product {
  id: number
  name: string
  brand: string
  price: number
  originalPrice?: number
  images?: string[]
  image?: string
  isLiked?: boolean
  category: string
  viewCount?: number
}

interface FixedBrandSliderProps {
  sectionTitle: string // New prop for the main section title
  bannerText: string // New prop for the text displayed on the banner
  brandId: string
  bannerImage: string
  products: Product[]
  seeMoreLink: string
}

// Mock data for the first instance (A.P.C.)
export const mockBrandDataAPC: FixedBrandSliderProps = {
  sectionTitle: "트렌드 브랜드 지갑",
  bannerText: "아페쎄",
  brandId: "trend-brand-wallet",
  bannerImage: "/placeholder.svg?height=200&width=600&text=트렌드+브랜드+지갑+아페쎄", // Hardcode for now, can be dynamic later
  products: [
    {
      id: 401,
      name: "하프문 지갑 - 블랙",
      brand: "A.P.C.",
      price: 250000,
      originalPrice: 300000,
      images: ["/placeholder.svg?height=300&width=300&text=APCWallet1"],
      isLiked: false,
      category: "지갑",
    },
    {
      id: 402,
      name: "제네바 미니 백 - 브라운",
      brand: "A.P.C.",
      price: 480000,
      originalPrice: 550000,
      images: ["/placeholder.svg?height=300&width=300&text=APCBag1"],
      isLiked: true,
      category: "가방",
    },
    {
      id: 403,
      name: "루이즈 스니커즈 - 화이트",
      brand: "A.P.C.",
      price: 180000,
      originalPrice: 220000,
      images: ["/placeholder.svg?height=300&width=300&text=APCSneakers1"],
      isLiked: false,
      category: "슈즈",
    },
    {
      id: 404,
      name: "데님 자켓 - 인디고",
      brand: "A.P.C.",
      price: 320000,
      originalPrice: 380000,
      images: ["/placeholder.svg?height=300&width=300&text=APCDenimJacket1"],
      isLiked: false,
      category: "아우터",
    },
    {
      id: 405,
      name: "로고 티셔츠 - 화이트",
      brand: "A.P.C.",
      price: 90000,
      originalPrice: 110000,
      images: ["/placeholder.svg?height=300&width=300&text=APCTshirt1"],
      isLiked: true,
      category: "상의",
    },
    {
      id: 406,
      name: "코튼 캡 - 네이비",
      brand: "A.P.C.",
      price: 70000,
      originalPrice: 85000,
      images: ["/placeholder.svg?height=300&width=300&text=APCCap1"],
      isLiked: false,
      category: "모자",
    },
    {
      id: 407,
      name: "가죽 벨트 - 블랙",
      brand: "A.P.C.",
      price: 150000,
      originalPrice: 180000,
      images: ["/placeholder.svg?height=300&width=300&text=APCBelt1"],
      isLiked: false,
      category: "액세서리",
    },
    {
      id: 408,
      name: "울 스웨터 - 그레이",
      brand: "A.P.C.",
      price: 280000,
      originalPrice: 330000,
      images: ["/placeholder.svg?height=300&width=300&text=APCSweater1"],
      isLiked: false,
      category: "상의",
    },
    {
      id: 409,
      name: "클래식 청바지 - 다크 워시",
      brand: "A.P.C.",
      price: 220000,
      originalPrice: 260000,
      images: ["/placeholder.svg?height=300&width=300&text=APCJeans1"],
      isLiked: false,
      category: "하의",
    },
  ],
  seeMoreLink: "/brand/trend-brand-wallet",
}

// Mock data for the second instance (Fits Slide)
export const mockBrandDataFits: FixedBrandSliderProps = {
  sectionTitle: "시즌제 광고배너",
  bannerText: "핏츠 슬라이드",
  brandId: "fits-slide",
  bannerImage: "/placeholder.svg?height=200&width=600&text=시즌제+광고배너+핏츠+슬라이드",
  products: [
    {
      id: 501,
      name: "슬림핏 데님 팬츠",
      brand: "Fits",
      price: 120000,
      originalPrice: 150000,
      images: ["/placeholder.svg?height=300&width=300&text=FitsJeans1"],
      isLiked: false,
      category: "하의",
    },
    {
      id: 502,
      name: "오버사이즈 후드티",
      brand: "Fits",
      price: 80000,
      originalPrice: 100000,
      images: ["/placeholder.svg?height=300&width=300&text=FitsHoodie1"],
      isLiked: true,
      category: "상의",
    },
    {
      id: 503,
      name: "스트라이프 셔츠",
      brand: "Fits",
      price: 70000,
      originalPrice: 90000,
      images: ["/placeholder.svg?height=300&width=300&text=FitsShirt1"],
      isLiked: false,
      category: "상의",
    },
    {
      id: 504,
      name: "와이드 레그 팬츠",
      brand: "Fits",
      price: 130000,
      originalPrice: 160000,
      images: ["/placeholder.svg?height=300&width=300&text=FitsWidePants1"],
      isLiked: false,
      category: "하의",
    },
    {
      id: 505,
      name: "크롭 가디건",
      brand: "Fits",
      price: 95000,
      originalPrice: 110000,
      images: ["/placeholder.svg?height=300&width=300&text=FitsCardigan1"],
      isLiked: true,
      category: "아우터",
    },
    {
      id: 506,
      name: "베이직 스니커즈",
      brand: "Fits",
      price: 110000,
      originalPrice: 130000,
      images: ["/placeholder.svg?height=300&width=300&text=FitsSneakers1"],
      isLiked: false,
      category: "슈즈",
    },
    {
      id: 507,
      name: "블레이저 자켓",
      brand: "Fits",
      price: 200000,
      originalPrice: 240000,
      images: ["/placeholder.svg?height=300&width=300&text=FitsBlazer1"],
      isLiked: false,
      category: "아우터",
    },
    {
      id: 508,
      name: "플리츠 스커트",
      brand: "Fits",
      price: 85000,
      originalPrice: 100000,
      images: ["/placeholder.svg?height=300&width=300&text=FitsSkirt1"],
      isLiked: false,
      category: "하의",
    },
    {
      id: 509,
      name: "캐시미어 니트",
      brand: "Fits",
      price: 180000,
      originalPrice: 210000,
      images: ["/placeholder.svg?height=300&width=300&text=FitsKnit1"],
      isLiked: false,
      category: "상의",
    },
  ],
  seeMoreLink: "/brand/fits-slide",
}

export default function FixedBrandSliderSection({
  sectionTitle, // Use this for the main section title
  bannerText, // Use this for the text displayed on the banner
  brandId,
  bannerImage,
  products,
  seeMoreLink,
}: FixedBrandSliderProps) {
  const [currentSlide, setCurrentSlide] = useState(0)
  const sliderRef = useRef<HTMLDivElement>(null)

  // Calculate items per slide for 3 full + 1/3 preview
  const itemsPerView = 3.33 // 3 full cards + 1/3 of the next card
  const totalSlides = Math.ceil(products.length / itemsPerView)

  const goToSlide = (index: number) => {
    setCurrentSlide(index)
    if (sliderRef.current) {
      // Calculate scroll position based on the width of one card and itemsPerView
      // We need to calculate the width of a single product card including its px-2 padding
      // The total width of the slider container is sliderRef.current.clientWidth
      // Each card takes 1/3.33 of the total width, so cardWidth = (sliderRef.current.clientWidth / itemsPerView)
      const cardContainerWidth = sliderRef.current.children[0].clientWidth // This is the width of one 'flex-shrink-0 w-[calc(100%/3.33)]' div
      sliderRef.current.scrollTo({
        left: index * cardContainerWidth, // Scroll by the width of one card container
        behavior: "smooth",
      })
    }
  }

  const nextSlide = () => {
    goToSlide((currentSlide + 1) % totalSlides)
  }

  const prevSlide = () => {
    goToSlide((currentSlide - 1 + totalSlides) % totalSlides)
  }

  return (
    <section className="bg-white pt-8 pb-16">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        {/* Section Title */}
        {sectionTitle && <h2 className="text-2xl font-bold mb-6 text-gray-900">{sectionTitle}</h2>}

        {/* Fixed Brand Banner */}
        <motion.div
          className="relative w-full h-[150px] md:h-[200px] rounded-lg overflow-hidden mb-6"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <Image
            src={bannerImage || "/placeholder.svg"}
            alt={`${bannerText} Banner`}
            layout="fill"
            objectFit="cover"
            className="brightness-75"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent p-4 flex flex-col justify-end">
            <span className="text-white text-lg md:text-xl font-semibold">{bannerText}</span>
          </div>
        </motion.div>

        {/* Product Slider */}
        <motion.div
          className="relative"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <div ref={sliderRef} className="flex overflow-x-scroll snap-x snap-mandatory scrollbar-hide">
            {products.map((product) => (
              <div
                key={product.id}
                className="flex-shrink-0 w-[calc(100%/3.33)] snap-start px-2" // 3 full cards + 1/3 preview
              >
                <ProductCard {...product} showImageNavigation={true} />
              </div>
            ))}
            {/* "더보기" button as the last item in the slider */}
            <div className="flex-shrink-0 w-[calc(100%/3.33)] snap-start px-2 flex items-center justify-center">
              <a
                href={seeMoreLink}
                className="bg-gray-900 text-white px-6 py-3 rounded-full text-sm font-medium hover:bg-gray-700 transition-colors shadow-md whitespace-nowrap"
              >
                더보기
              </a>
            </div>
          </div>

          {/* Navigation buttons - only show if more than 1 slide */}
          {totalSlides > 1 && (
            <>
              <motion.button
                onClick={prevSlide}
                className="absolute left-0 top-1/2 -translate-y-1/2 w-10 h-10 bg-white shadow-lg rounded-full flex items-center justify-center hover:bg-gray-50 transition-all duration-300 z-10 -ml-5"
                initial={{ opacity: 0.3 }}
                whileHover={{ opacity: 1 }}
                whileTap={{ opacity: 1 }}
              >
                <ChevronLeft className="w-5 h-5 text-gray-600" />
              </motion.button>
              <motion.button
                onClick={nextSlide}
                className="absolute right-0 top-1/2 -translate-y-1/2 w-10 h-10 bg-white shadow-lg rounded-full flex items-center justify-center hover:bg-gray-50 transition-all duration-300 z-10 -mr-5"
                initial={{ opacity: 0.3 }}
                whileHover={{ opacity: 1 }}
                whileTap={{ opacity: 1 }}
              >
                <ChevronRight className="w-5 h-6 text-gray-600" />
              </motion.button>
            </>
          )}

          {/* Pagination Dots - only show if more than 1 slide */}
          {totalSlides > 1 && (
            <div className="flex justify-center mt-4 space-x-2">
              {Array.from({ length: totalSlides }).map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToSlide(index)}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    index === currentSlide ? "bg-gray-800 scale-125" : "bg-gray-300 hover:bg-gray-500"
                  }`}
                  aria-label={`슬라이드 ${index + 1}로 이동`}
                />
              ))}
            </div>
          )}
        </motion.div>
      </div>
    </section>
  )
}
