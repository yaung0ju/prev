"use client"

import { useRef } from "react"
import { motion } from "framer-motion"
import ProductCard from "./product-card"

// Mock data
const recommendedProducts = [
  {
    id: 1,
    name: "클래식 토트백",
    brand: "CHANEL",
    price: 4500000,
    originalPrice: 5000000,
    image: "/placeholder.svg?height=300&width=300",
    isLiked: false,
  },
  {
    id: 2,
    name: "골드 체인 목걸이",
    brand: "TIFFANY & CO.",
    price: 1200000,
    image: "/placeholder.svg?height=300&width=300",
    isLiked: true,
  },
  {
    id: 3,
    name: "레더 크로스백",
    brand: "LOUIS VUITTON",
    price: 3200000,
    image: "/placeholder.svg?height=300&width=300",
    isLiked: false,
  },
  {
    id: 4,
    name: "실버 브레이슬릿",
    brand: "CARTIER",
    price: 2800000,
    originalPrice: 3200000,
    image: "/placeholder.svg?height=300&width=300",
    isLiked: false,
  },
  {
    id: 5,
    name: "미니 숄더백",
    brand: "HERMÈS",
    price: 6500000,
    image: "/placeholder.svg?height=300&width=300",
    isLiked: true,
  },
]

export default function RecommendationSlider() {
  const scrollRef = useRef<HTMLDivElement>(null)

  const scroll = (direction: "left" | "right") => {
    if (scrollRef.current) {
      const scrollAmount = 280
      scrollRef.current.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      })
    }
  }

  return (
    <section className="bg-gray-50 rounded-lg p-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-bold text-gray-900">인기 추천 상품</h2>
        <button className="text-sm text-pink-500 hover:text-pink-600">더보기</button>
      </div>

      <div className="relative">
        <div
          ref={scrollRef}
          className="flex space-x-4 overflow-x-auto scrollbar-hide pb-2"
          style={{
            scrollbarWidth: "none",
            msOverflowStyle: "none",
            WebkitScrollbar: { display: "none" },
          }}
        >
          {recommendedProducts.map((product, index) => (
            <motion.div
              key={product.id}
              className="flex-none w-48"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
            >
              <ProductCard {...product} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
