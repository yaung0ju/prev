"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronDown, ChevronUp } from "lucide-react"
import Image from "next/image"

interface Brand {
  id: number
  name: string
  nameEN: string
  image: string
  category: string
}

interface BrandGroup {
  letter: string
  brands: Brand[]
}

const brandData: Brand[] = [
  // A
  {
    id: 1,
    name: "아크네 스튜디오",
    nameEN: "ACNE STUDIOS",
    image: "/placeholder.svg?height=48&width=48",
    category: "패션",
  },
  {
    id: 2,
    name: "알렉산더 맥퀸",
    nameEN: "ALEXANDER MCQUEEN",
    image: "/placeholder.svg?height=48&width=48",
    category: "패션",
  },
  { id: 3, name: "아미", nameEN: "AMI", image: "/placeholder.svg?height=48&width=48", category: "패션" },

  // B
  { id: 4, name: "발렌시아가", nameEN: "BALENCIAGA", image: "/placeholder.svg?height=48&width=48", category: "패션" },
  {
    id: 5,
    name: "보테가베네타",
    nameEN: "BOTTEGA VENETA",
    image: "/placeholder.svg?height=48&width=48",
    category: "가방",
  },
  { id: 6, name: "버버리", nameEN: "BURBERRY", image: "/placeholder.svg?height=48&width=48", category: "패션" },

  // C
  { id: 7, name: "샤넬", nameEN: "CHANEL", image: "/placeholder.svg?height=48&width=48", category: "럭셔리" },
  { id: 8, name: "까르띠에", nameEN: "CARTIER", image: "/placeholder.svg?height=48&width=48", category: "주얼리" },
  { id: 9, name: "셀린느", nameEN: "CELINE", image: "/placeholder.svg?height=48&width=48", category: "가방" },
  { id: 10, name: "클로에", nameEN: "CHLOE", image: "/placeholder.svg?height=48&width=48", category: "가방" },

  // D
  { id: 11, name: "디올", nameEN: "DIOR", image: "/placeholder.svg?height=48&width=48", category: "뷰티" },
  {
    id: 12,
    name: "돌체앤가바나",
    nameEN: "DOLCE & GABBANA",
    image: "/placeholder.svg?height=48&width=48",
    category: "패션",
  },

  // F
  { id: 13, name: "펜디", nameEN: "FENDI", image: "/placeholder.svg?height=48&width=48", category: "가방" },
  { id: 14, name: "페라가모", nameEN: "FERRAGAMO", image: "/placeholder.svg?height=48&width=48", category: "패션" },

  // G
  { id: 15, name: "구찌", nameEN: "GUCCI", image: "/placeholder.svg?height=48&width=48", category: "패션" },
  { id: 16, name: "지방시", nameEN: "GIVENCHY", image: "/placeholder.svg?height=48&width=48", category: "패션" },

  // H
  { id: 17, name: "에르메스", nameEN: "HERMÈS", image: "/placeholder.svg?height=48&width=48", category: "럭셔리" },
  { id: 18, name: "휴고보스", nameEN: "HUGO BOSS", image: "/placeholder.svg?height=48&width=48", category: "패션" },

  // L
  { id: 19, name: "루이비통", nameEN: "LOUIS VUITTON", image: "/placeholder.svg?height=48&width=48", category: "가방" },
  { id: 20, name: "로에베", nameEN: "LOEWE", image: "/placeholder.svg?height=48&width=48", category: "가방" },

  // M
  { id: 21, name: "마르니", nameEN: "MARNI", image: "/placeholder.svg?height=48&width=48", category: "패션" },
  { id: 22, name: "몽클레어", nameEN: "MONCLER", image: "/placeholder.svg?height=48&width=48", category: "패션" },

  // O
  { id: 23, name: "오메가", nameEN: "OMEGA", image: "/placeholder.svg?height=48&width=48", category: "시계" },
  { id: 24, name: "오프화이트", nameEN: "OFF-WHITE", image: "/placeholder.svg?height=48&width=48", category: "패션" },

  // P
  { id: 25, name: "프라다", nameEN: "PRADA", image: "/placeholder.svg?height=48&width=48", category: "가방" },
  {
    id: 26,
    name: "필립플레인",
    nameEN: "PHILIPP PLEIN",
    image: "/placeholder.svg?height=48&width=48",
    category: "패션",
  },

  // R
  { id: 27, name: "롤렉스", nameEN: "ROLEX", image: "/placeholder.svg?height=48&width=48", category: "시계" },
  { id: 28, name: "릭오웬스", nameEN: "RICK OWENS", image: "/placeholder.svg?height=48&width=48", category: "패션" },

  // S
  { id: 29, name: "생로랑", nameEN: "SAINT LAURENT", image: "/placeholder.svg?height=48&width=48", category: "패션" },
  {
    id: 30,
    name: "스텔라맥카트니",
    nameEN: "STELLA MCCARTNEY",
    image: "/placeholder.svg?height=48&width=48",
    category: "패션",
  },

  // T
  { id: 31, name: "티파니", nameEN: "TIFFANY & CO.", image: "/placeholder.svg?height=48&width=48", category: "주얼리" },
  { id: 32, name: "톰포드", nameEN: "TOM FORD", image: "/placeholder.svg?height=48&width=48", category: "패션" },

  // V
  { id: 33, name: "발렌티노", nameEN: "VALENTINO", image: "/placeholder.svg?height=48&width=48", category: "패션" },
  { id: 34, name: "베르사체", nameEN: "VERSACE", image: "/placeholder.svg?height=48&width=48", category: "패션" },
]

// Group brands by first letter
const groupBrandsByLetter = (brands: Brand[]): BrandGroup[] => {
  const groups: { [key: string]: Brand[] } = {}

  brands.forEach((brand) => {
    const firstLetter = brand.nameEN.charAt(0).toUpperCase()
    if (!groups[firstLetter]) {
      groups[firstLetter] = []
    }
    groups[firstLetter].push(brand)
  })

  // Sort groups alphabetically and sort brands within each group
  return Object.keys(groups)
    .sort()
    .map((letter) => ({
      letter,
      brands: groups[letter].sort((a, b) => a.nameEN.localeCompare(b.nameEN)),
    }))
}

interface BrandCategoryListProps {
  onBrandClick?: (brand: Brand) => void
  loadingBrandId?: number | null
}

export default function BrandCategoryList({ onBrandClick, loadingBrandId }: BrandCategoryListProps) {
  const [expandedGroups, setExpandedGroups] = useState<string[]>([])
  const brandGroups = groupBrandsByLetter(brandData)

  const toggleGroup = (letter: string) => {
    setExpandedGroups((prev) => (prev.includes(letter) ? prev.filter((l) => l !== letter) : [...prev, letter]))
  }

  const handleBrandClick = (brand: Brand) => {
    onBrandClick?.(brand)
  }

  return (
    <div className="space-y-2">
      {brandGroups.map((group, groupIndex) => (
        <div key={group.letter} className="border border-gray-200 rounded-lg overflow-hidden">
          {/* Group Header */}
          <motion.button
            className="w-full min-h-12 px-4 py-3 bg-gray-50 hover:bg-gray-100 flex items-center justify-between transition-colors"
            onClick={() => toggleGroup(group.letter)}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2, delay: groupIndex * 0.05 }}
          >
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-pink-500 text-white rounded-full flex items-center justify-center font-bold text-sm">
                {group.letter}
              </div>
              <span className="font-medium text-gray-900">
                {group.letter} ({group.brands.length}개 브랜드)
              </span>
            </div>

            {expandedGroups.includes(group.letter) ? (
              <ChevronUp className="w-5 h-5 text-gray-500" />
            ) : (
              <ChevronDown className="w-5 h-5 text-gray-500" />
            )}
          </motion.button>

          {/* Group Content */}
          <AnimatePresence>
            {expandedGroups.includes(group.letter) && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3, ease: "easeInOut" }}
                className="overflow-hidden"
              >
                <div className="p-4 bg-white">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {group.brands.map((brand, brandIndex) => (
                      <motion.button
                        key={brand.id}
                        className="min-h-12 p-3 bg-white border border-gray-200 rounded-lg shadow-sm hover:shadow-md hover:border-pink-300 transition-all duration-200 text-left group"
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.2, delay: brandIndex * 0.05 }}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => handleBrandClick(brand)}
                        disabled={loadingBrandId === brand.id}
                      >
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                            <Image
                              src={brand.image || "/placeholder.svg"}
                              alt={brand.name}
                              width={40}
                              height={40}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-900 truncate group-hover:text-pink-600 transition-colors">
                              {brand.name}
                            </p>
                            <p className="text-xs text-gray-500 truncate">{brand.nameEN}</p>
                            <p className="text-xs text-pink-500 mt-1">{brand.category}</p>
                          </div>
                          {loadingBrandId === brand.id && (
                            <div className="w-4 h-4 border-2 border-pink-300 border-t-pink-500 rounded-full animate-spin flex-shrink-0"></div>
                          )}
                        </div>
                      </motion.button>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      ))}
    </div>
  )
}
