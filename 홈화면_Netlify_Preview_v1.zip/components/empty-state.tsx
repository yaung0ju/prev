"use client"

import { motion } from "framer-motion"
import { Search, Clock } from "lucide-react"

interface EmptyStateProps {
  type: "search" | "recent"
  onAction?: () => void
  actionLabel?: string
}

export function EmptyState({ type, onAction, actionLabel }: EmptyStateProps) {
  if (type === "search") {
    return (
      <motion.div
        className="text-center py-12"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Search className="w-8 h-8 text-gray-400" />
        </div>
        <p className="text-sm text-gray-500 mb-4">검색 결과가 없습니다. 다른 키워드를 입력해 보세요.</p>
        {onAction && actionLabel && (
          <button
            onClick={onAction}
            className="px-4 py-2 bg-pink-500 text-white rounded-lg hover:bg-pink-600 transition-colors text-sm"
          >
            {actionLabel}
          </button>
        )}
      </motion.div>
    )
  }

  if (type === "recent") {
    return (
      <div className="text-center py-8">
        <Clock className="w-12 h-12 text-gray-300 mx-auto mb-4" />
        <p className="text-sm text-gray-500 mb-4">최근 본 브랜드가 없습니다</p>
        {onAction && actionLabel && (
          <button onClick={onAction} className="text-pink-500 hover:text-pink-600 font-medium text-sm">
            {actionLabel}
          </button>
        )}
      </div>
    )
  }

  return null
}
