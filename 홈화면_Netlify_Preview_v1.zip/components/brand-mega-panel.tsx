"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Search, ChevronDown, ChevronUp, Star, ArrowUpDown, X } from "lucide-react"
import Image from "next/image"
import { useDebounce } from "@/hooks/useDebounce"

interface Brand {
  id: number
  name: string
  nameEN: string
  image: string
  category: string
  isPopular?: boolean
}

interface BrandGroup {
  letter: string
  brands: Brand[]
}

const brandData: Brand[] = [
  // Popular brands
  {
    id: 1,
    name: "샤넬",
    nameEN: "CHANEL",
    image: "/placeholder.svg?height=32&width=32",
    category: "럭셔리",
    isPopular: true,
  },
  {
    id: 2,
    name: "루이비통",
    nameEN: "LOUIS VUITTON",
    image: "/placeholder.svg?height=32&width=32",
    category: "가방",
    isPopular: true,
  },
  {
    id: 3,
    name: "에르메스",
    nameEN: "HERMÈS",
    image: "/placeholder.svg?height=32&width=32",
    category: "럭셔리",
    isPopular: true,
  },
  {
    id: 4,
    name: "구찌",
    nameEN: "GUCCI",
    image: "/placeholder.svg?height=32&width=32",
    category: "패션",
    isPopular: true,
  },
  {
    id: 5,
    name: "프라다",
    nameEN: "PRADA",
    image: "/placeholder.svg?height=32&width=32",
    category: "가방",
    isPopular: true,
  },
  {
    id: 6,
    name: "디올",
    nameEN: "DIOR",
    image: "/placeholder.svg?height=32&width=32",
    category: "뷰티",
    isPopular: true,
  },

  // A
  {
    id: 7,
    name: "아크네 스튜디오",
    nameEN: "ACNE STUDIOS",
    image: "/placeholder.svg?height=32&width=32",
    category: "패션",
  },
  {
    id: 8,
    name: "알렉산더 맥퀸",
    nameEN: "ALEXANDER MCQUEEN",
    image: "/placeholder.svg?height=32&width=32",
    category: "패션",
  },
  { id: 9, name: "아미", nameEN: "AMI", image: "/placeholder.svg?height=32&width=32", category: "패션" },

  // B
  { id: 10, name: "발렌시아가", nameEN: "BALENCIAGA", image: "/placeholder.svg?height=32&width=32", category: "패션" },
  {
    id: 11,
    name: "보테가베네타",
    nameEN: "BOTTEGA VENETA",
    image: "/placeholder.svg?height=32&width=32",
    category: "가방",
  },
  { id: 12, name: "버버리", nameEN: "BURBERRY", image: "/placeholder.svg?height=32&width=32", category: "패션" },

  // C
  { id: 13, name: "까르띠에", nameEN: "CARTIER", image: "/placeholder.svg?height=32&width=32", category: "주얼리" },
  { id: 14, name: "셀린느", nameEN: "CELINE", image: "/placeholder.svg?height=32&width=32", category: "가방" },
  { id: 15, name: "클로에", nameEN: "CHLOE", image: "/placeholder.svg?height=32&width=32", category: "가방" },

  // F
  { id: 16, name: "펜디", nameEN: "FENDI", image: "/placeholder.svg?height=32&width=32", category: "가방" },
  { id: 17, name: "페라가모", nameEN: "FERRAGAMO", image: "/placeholder.svg?height=32&width=32", category: "패션" },

  // G
  { id: 18, name: "지방시", nameEN: "GIVENCHY", image: "/placeholder.svg?height=32&width=32", category: "패션" },

  // L
  { id: 19, name: "로에베", nameEN: "LOEWE", image: "/placeholder.svg?height=32&width=32", category: "가방" },

  // M
  { id: 20, name: "마르니", nameEN: "MARNI", image: "/placeholder.svg?height=32&width=32", category: "패션" },
  { id: 21, name: "몽클레어", nameEN: "MONCLER", image: "/placeholder.svg?height=32&width=32", category: "패션" },

  // O
  { id: 22, name: "오메가", nameEN: "OMEGA", image: "/placeholder.svg?height=32&width=32", category: "시계" },
  { id: 23, name: "오프화이트", nameEN: "OFF-WHITE", image: "/placeholder.svg?height=32&width=32", category: "패션" },

  // R
  { id: 24, name: "롤렉스", nameEN: "ROLEX", image: "/placeholder.svg?height=32&width=32", category: "시계" },
  { id: 25, name: "릭오웬스", nameEN: "RICK OWENS", image: "/placeholder.svg?height=32&width=32", category: "패션" },

  // S
  { id: 26, name: "생로랑", nameEN: "SAINT LAURENT", image: "/placeholder.svg?height=32&width=32", category: "패션" },
  {
    id: 27,
    name: "스텔라맥카트니",
    nameEN: "STELLA MCCARTNEY",
    image: "/placeholder.svg?height=32&width=32",
    category: "패션",
  },

  // T
  { id: 28, name: "티파니", nameEN: "TIFFANY & CO.", image: "/placeholder.svg?height=32&width=32", category: "주얼리" },
  { id: 29, name: "톰포드", nameEN: "TOM FORD", image: "/placeholder.svg?height=32&width=32", category: "패션" },

  // V
  { id: 30, name: "발렌티노", nameEN: "VALENTINO", image: "/placeholder.svg?height=32&width=32", category: "패션" },
  { id: 31, name: "베르사체", nameEN: "VERSACE", image: "/placeholder.svg?height=32&width=32", category: "패션" },
]

interface BrandMegaPanelProps {
  isOpen: boolean
  onClose: () => void
  onBrandClick?: (brand: Brand) => void
}

export default function BrandMegaPanel({ isOpen, onClose, onBrandClick }: BrandMegaPanelProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [expandedGroups, setExpandedGroups] = useState<string[]>([])
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc")
  const [filteredBrands, setFilteredBrands] = useState(brandData)
  const [sortType, setSortType] = useState<"popular" | "newest">("popular")
  const panelRef = useRef<HTMLDivElement>(null)

  const debouncedSearchQuery = useDebounce(searchQuery, 300)

  // Filter brands based on search query
  useEffect(() => {
    if (debouncedSearchQuery.trim() === "") {
      setFilteredBrands(brandData)
    } else {
      const filtered = brandData.filter(
        (brand) =>
          brand.name.toLowerCase().includes(debouncedSearchQuery.toLowerCase()) ||
          brand.nameEN.toLowerCase().includes(debouncedSearchQuery.toLowerCase()) ||
          brand.category.toLowerCase().includes(debouncedSearchQuery.toLowerCase()),
      )
      setFilteredBrands(filtered)
    }
  }, [debouncedSearchQuery])

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (panelRef.current && !panelRef.current.contains(event.target as Node)) {
        onClose()
      }
    }

    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside)
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [isOpen, onClose])

  // Group brands by first letter
  const groupBrandsByLetter = (brands: Brand[]): BrandGroup[] => {
    const groups: { [key: string]: Brand[] } = {}

    brands.forEach((brand) => {
      const firstLetter = brand.nameEN.charAt(0).toUpperCase()
      if (!groups[firstLetter]) {
        groups[firstLetter] = []
      }
      groups[firstLetter].push(brand)
    })

    const sortedGroups = Object.keys(groups)
      .sort((a, b) => (sortOrder === "asc" ? a.localeCompare(b) : b.localeCompare(a)))
      .map((letter) => ({
        letter,
        brands: groups[letter].sort((a, b) =>
          sortOrder === "asc" ? a.nameEN.localeCompare(b.nameEN) : b.nameEN.localeCompare(a.nameEN),
        ),
      }))

    return sortedGroups
  }

  const brandGroups = groupBrandsByLetter(filteredBrands.filter((brand) => !brand.isPopular))
  const popularBrands = filteredBrands.filter((brand) => brand.isPopular)

  const toggleGroup = (letter: string) => {
    setExpandedGroups((prev) => (prev.includes(letter) ? prev.filter((l) => l !== letter) : [...prev, letter]))
  }

  const toggleSortOrder = () => {
    setSortOrder((prev) => (prev === "asc" ? "desc" : "asc"))
  }

  const handleBrandClick = (brand: Brand) => {
    onBrandClick?.(brand)
    onClose()
  }

  const clearSearch = () => {
    setSearchQuery("")
  }

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose()
    }
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Mobile Backdrop */}
          <motion.div
            className="fixed inset-0 bg-black bg-opacity-50 z-40 md:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={handleBackdropClick}
          />

          {/* Mega Panel */}
          <motion.div
            ref={panelRef}
            className="absolute left-0 right-0 top-full bg-white shadow-xl z-50 max-h-[80vh] overflow-hidden md:relative md:max-h-[70vh]"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3, ease: "easeOut" }}
          >
            {/* Mobile Full Screen */}
            <div className="md:hidden fixed inset-0 bg-white z-50 flex flex-col">
              <div className="flex-shrink-0 p-4">
                {/* Mobile Header */}
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold">브랜드 목록</h2>
                  <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full" aria-label="닫기">
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Search & Sort */}
                <div className="space-y-3 mb-6">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                      type="text"
                      placeholder="브랜드명 검색"
                      className="w-full pl-10 pr-10 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                    {searchQuery && (
                      <button
                        onClick={clearSearch}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1 hover:bg-gray-100 rounded-full"
                      >
                        <X className="w-3 h-3 text-gray-400" />
                      </button>
                    )}
                  </div>
                  <button
                    onClick={toggleSortOrder}
                    className="flex items-center space-x-2 px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
                  >
                    <ArrowUpDown className="w-4 h-4" />
                    <span className="text-sm">{sortOrder === "asc" ? "A-Z 정렬" : "Z-A 정렬"}</span>
                  </button>
                </div>
              </div>

              {/* Scrollable Content */}
              <div className="flex-1 overflow-y-auto px-4 pb-4" style={{ WebkitOverflowScrolling: "touch" }}>
                {/* Popular Brands */}
                {popularBrands.length > 0 && (
                  <div className="mb-6">
                    <div className="flex items-center space-x-2 mb-3">
                      <Star className="w-4 h-4 text-pink-500" />
                      <h3 className="font-medium text-gray-900">인기 브랜드</h3>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      {popularBrands.map((brand) => (
                        <button
                          key={brand.id}
                          className="min-h-12 px-4 py-2 bg-pink-50 hover:bg-pink-100 rounded-lg transition-colors text-left"
                          onClick={() => handleBrandClick(brand)}
                        >
                          <div className="flex items-center space-x-2">
                            <Image
                              src={brand.image || "/placeholder.svg"}
                              alt={brand.name}
                              width={24}
                              height={24}
                              className="rounded"
                            />
                            <div className="min-w-0 flex-1">
                              <p className="text-sm font-medium text-gray-900 truncate">{brand.name}</p>
                              <p className="text-xs text-gray-500 truncate">{brand.nameEN}</p>
                            </div>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Brand Groups */}
                <div className="space-y-2">
                  {brandGroups.map((group) => (
                    <div key={group.letter} className="border border-gray-200 rounded-lg overflow-hidden">
                      <button
                        className="w-full min-h-12 px-4 py-3 bg-gray-50 hover:bg-gray-100 flex justify-between items-center font-medium transition-colors"
                        onClick={() => toggleGroup(group.letter)}
                      >
                        <span>
                          {group.letter} ({group.brands.length})
                        </span>
                        {expandedGroups.includes(group.letter) ? (
                          <ChevronUp className="w-4 h-4" />
                        ) : (
                          <ChevronDown className="w-4 h-4" />
                        )}
                      </button>

                      <AnimatePresence>
                        {expandedGroups.includes(group.letter) && (
                          <motion.div
                            initial={{ height: 0 }}
                            animate={{ height: "auto" }}
                            exit={{ height: 0 }}
                            transition={{ duration: 0.2 }}
                            className="overflow-hidden"
                          >
                            <ul className="bg-white">
                              {group.brands.map((brand) => (
                                <li key={brand.id}>
                                  <button
                                    className="w-full min-h-12 px-4 py-2 hover:bg-pink-50 transition-colors text-left"
                                    onClick={() => handleBrandClick(brand)}
                                  >
                                    <div className="flex items-center space-x-3">
                                      <Image
                                        src={brand.image || "/placeholder.svg"}
                                        alt={brand.name}
                                        width={24}
                                        height={24}
                                        className="rounded"
                                      />
                                      <div className="min-w-0 flex-1">
                                        <p className="text-sm font-medium text-gray-900 truncate">{brand.name}</p>
                                        <p className="text-xs text-gray-500 truncate">{brand.nameEN}</p>
                                      </div>
                                    </div>
                                  </button>
                                </li>
                              ))}
                            </ul>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Desktop Version */}
            <div className="hidden md:block max-h-[80vh] overflow-y-auto">
              <div className="p-6">
                {/* Search & Sort Row */}
                <div className="flex items-center space-x-4 mb-6">
                  <div className="relative flex-1 max-w-md">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                      type="text"
                      placeholder="브랜드명 검색"
                      className="w-full pl-10 pr-10 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                    {searchQuery && (
                      <button
                        onClick={clearSearch}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1 hover:bg-gray-100 rounded-full"
                      >
                        <X className="w-3 h-3 text-gray-400" />
                      </button>
                    )}
                  </div>
                  <button
                    onClick={toggleSortOrder}
                    className="flex items-center space-x-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
                  >
                    <ArrowUpDown className="w-4 h-4" />
                    <span className="text-sm">{sortOrder === "asc" ? "A-Z 정렬" : "Z-A 정렬"}</span>
                  </button>
                </div>

                <div className="grid grid-cols-12 gap-6">
                  {/* Popular Brands Column */}
                  {popularBrands.length > 0 && (
                    <div className="col-span-3">
                      <div className="flex items-center space-x-2 mb-4">
                        <Star className="w-4 h-4 text-pink-500" />
                        <h3 className="font-medium text-gray-900">인기 브랜드</h3>
                      </div>
                      <div className="space-y-2">
                        {popularBrands.map((brand) => (
                          <button
                            key={brand.id}
                            className="w-full p-3 bg-pink-50 hover:bg-pink-100 rounded-lg transition-colors text-left"
                            onClick={() => handleBrandClick(brand)}
                          >
                            <div className="flex items-center space-x-3">
                              <Image
                                src={brand.image || "/placeholder.svg"}
                                alt={brand.name}
                                width={32}
                                height={32}
                                className="rounded"
                              />
                              <div className="min-w-0 flex-1">
                                <p className="text-sm font-medium text-gray-900 truncate">{brand.name}</p>
                                <p className="text-xs text-gray-500 truncate">{brand.nameEN}</p>
                              </div>
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Brand Groups */}
                  <div className={popularBrands.length > 0 ? "col-span-9" : "col-span-12"}>
                    <div className="grid grid-cols-3 gap-4 max-h-96 overflow-y-auto">
                      {brandGroups.map((group) => (
                        <div key={group.letter} className="space-y-2">
                          <button
                            className="w-full p-3 bg-gray-50 hover:bg-gray-100 rounded-lg flex justify-between items-center font-medium transition-colors"
                            onClick={() => toggleGroup(group.letter)}
                          >
                            <span>
                              {group.letter} ({group.brands.length})
                            </span>
                            {expandedGroups.includes(group.letter) ? (
                              <ChevronUp className="w-4 h-4" />
                            ) : (
                              <ChevronDown className="w-4 h-4" />
                            )}
                          </button>

                          <AnimatePresence>
                            {expandedGroups.includes(group.letter) && (
                              <motion.div
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: "auto" }}
                                exit={{ opacity: 0, height: 0 }}
                                transition={{ duration: 0.2 }}
                                className="overflow-hidden"
                              >
                                <ul className="space-y-1">
                                  {group.brands.map((brand) => (
                                    <li key={brand.id}>
                                      <button
                                        className="w-full p-2 hover:bg-pink-50 rounded transition-colors text-left text-sm"
                                        onClick={() => handleBrandClick(brand)}
                                      >
                                        <div className="flex items-center space-x-2">
                                          <Image
                                            src={brand.image || "/placeholder.svg"}
                                            alt={brand.name}
                                            width={20}
                                            height={20}
                                            className="rounded"
                                          />
                                          <div className="min-w-0 flex-1">
                                            <p className="font-medium text-gray-900 truncate">{brand.name}</p>
                                            <p className="text-xs text-gray-500 truncate">{brand.nameEN}</p>
                                          </div>
                                        </div>
                                      </button>
                                    </li>
                                  ))}
                                </ul>
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}
