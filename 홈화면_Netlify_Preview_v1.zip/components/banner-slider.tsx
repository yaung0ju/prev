"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Image from "next/image"

const bannerImages = [
  {
    id: 1,
    src: "/placeholder.svg?height=400&width=1200",
    alt: "Banner 1",
    title: "럭셔리 컬렉션",
    subtitle: "프리미엄 브랜드의 새로운 시즌",
    link: "/collection/luxury",
  },
  {
    id: 2,
    src: "/placeholder.svg?height=400&width=1200",
    alt: "Banner 2",
    title: "신상품 출시",
    subtitle: "지금 만나보는 최신 트렌드",
    link: "/new-arrivals",
  },
  {
    id: 3,
    src: "/placeholder.svg?height=400&width=1200",
    alt: "Banner 3",
    title: "특별 할인",
    subtitle: "한정 기간 특가 혜택",
    link: "/sale",
  },
  {
    id: 4,
    src: "/placeholder.svg?height=400&width=1200",
    alt: "Banner 4",
    title: "VIP 멤버십",
    subtitle: "독점 혜택과 우선 구매권",
    link: "/membership",
  },
]

export default function BannerSlider() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const [isAutoPlaying, setIsAutoPlaying] = useState(true)
  const [isPaused, setIsPaused] = useState(false)
  const pauseTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const autoPlayIntervalRef = useRef<NodeJS.Timeout | null>(null)

  // Auto play logic
  useEffect(() => {
    if (!isAutoPlaying || isPaused) {
      if (autoPlayIntervalRef.current) {
        clearInterval(autoPlayIntervalRef.current)
      }
      return
    }

    autoPlayIntervalRef.current = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % bannerImages.length)
    }, 5000)

    return () => {
      if (autoPlayIntervalRef.current) {
        clearInterval(autoPlayIntervalRef.current)
      }
    }
  }, [isAutoPlaying, isPaused])

  const handleBannerClick = () => {
    // Pause auto play
    setIsPaused(true)

    // Clear existing timeout
    if (pauseTimeoutRef.current) {
      clearTimeout(pauseTimeoutRef.current)
    }

    // Resume after 3 seconds of inactivity
    pauseTimeoutRef.current = setTimeout(() => {
      setIsPaused(false)
    }, 3000)

    // Navigate to banner link
    const currentBanner = bannerImages[currentSlide]
    console.log(`Navigate to ${currentBanner.link}`)
  }

  const goToSlide = (index: number) => {
    setCurrentSlide(index)
    setIsPaused(true)

    if (pauseTimeoutRef.current) {
      clearTimeout(pauseTimeoutRef.current)
    }

    pauseTimeoutRef.current = setTimeout(() => {
      setIsPaused(false)
    }, 3000)
  }

  // Touch/swipe handling
  const [touchStart, setTouchStart] = useState<number | null>(null)
  const [touchEnd, setTouchEnd] = useState<number | null>(null)

  const minSwipeDistance = 50

  const onTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null)
    setTouchStart(e.targetTouches[0].clientX)
  }

  const onTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX)
  }

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return

    const distance = touchStart - touchEnd
    const isLeftSwipe = distance > minSwipeDistance
    const isRightSwipe = distance < -minSwipeDistance

    if (isLeftSwipe) {
      setCurrentSlide((prev) => (prev + 1) % bannerImages.length)
      setIsPaused(true)

      if (pauseTimeoutRef.current) {
        clearTimeout(pauseTimeoutRef.current)
      }

      pauseTimeoutRef.current = setTimeout(() => {
        setIsPaused(false)
      }, 3000)
    }

    if (isRightSwipe) {
      setCurrentSlide((prev) => (prev - 1 + bannerImages.length) % bannerImages.length)
      setIsPaused(true)

      if (pauseTimeoutRef.current) {
        clearTimeout(pauseTimeoutRef.current)
      }

      pauseTimeoutRef.current = setTimeout(() => {
        setIsPaused(false)
      }, 3000)
    }
  }

  return (
    <div
      className="relative w-full h-64 md:h-96 lg:h-[500px] overflow-hidden bg-gray-100 cursor-pointer"
      onClick={handleBannerClick}
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
    >
      <AnimatePresence mode="wait">
        <motion.div
          key={currentSlide}
          className="absolute inset-0"
          initial={{ opacity: 0, x: 300 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -300 }}
          transition={{ duration: 0.6, ease: "easeInOut" }}
        >
          <Image
            src={bannerImages[currentSlide].src || "/placeholder.svg"}
            alt={bannerImages[currentSlide].alt}
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center">
            <div className="text-center text-white max-w-4xl px-4">
              <motion.h1
                className="text-3xl md:text-5xl lg:text-6xl font-bold mb-4"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
              >
                {bannerImages[currentSlide].title}
              </motion.h1>
              <motion.p
                className="text-lg md:text-xl lg:text-2xl opacity-90"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
              >
                {bannerImages[currentSlide].subtitle}
              </motion.p>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Indicators */}
      <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex space-x-3">
        {bannerImages.map((_, index) => (
          <button
            key={index}
            onClick={(e) => {
              e.stopPropagation()
              goToSlide(index)
            }}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              index === currentSlide ? "bg-white scale-125" : "bg-white bg-opacity-50 hover:bg-opacity-75"
            }`}
            aria-label={`슬라이드 ${index + 1}로 이동`}
          />
        ))}
      </div>

      {/* Slide Counter */}
      <div className="absolute bottom-6 right-6 bg-black bg-opacity-50 text-white text-sm px-3 py-1 rounded-full">
        {currentSlide + 1}/{bannerImages.length}
      </div>

      {/* Pause indicator */}
      {isPaused && (
        <div className="absolute top-6 left-6 bg-black bg-opacity-50 text-white text-sm px-3 py-1 rounded-full">
          일시정지
        </div>
      )}
    </div>
  )
}
