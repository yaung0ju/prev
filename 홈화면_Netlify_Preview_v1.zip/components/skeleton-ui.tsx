"use client"

export function BrandCardSkeleton() {
  return (
    <div className="p-4 bg-white border border-gray-200 rounded-lg shadow animate-pulse">
      <div className="flex items-center space-x-3">
        <div className="w-12 h-12 bg-gray-200 rounded-lg flex-shrink-0"></div>
        <div className="flex-1 min-w-0">
          <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
          <div className="h-3 bg-gray-200 rounded w-1/2 mb-1"></div>
          <div className="h-3 bg-gray-200 rounded w-1/3"></div>
        </div>
      </div>
    </div>
  )
}

export function SearchSkeleton() {
  return (
    <div className="grid grid-cols-2 gap-4">
      {Array.from({ length: 8 }).map((_, index) => (
        <BrandCardSkeleton key={index} />
      ))}
    </div>
  )
}

export function KeywordSkeleton() {
  return (
    <div className="flex flex-wrap gap-2">
      {Array.from({ length: 10 }).map((_, index) => (
        <div
          key={index}
          className="h-8 bg-gray-200 rounded-full animate-pulse"
          style={{ width: `${Math.random() * 40 + 60}px` }}
        ></div>
      ))}
    </div>
  )
}

export function TabContentSkeleton({ type }: { type: "keywords" | "brands" }) {
  if (type === "keywords") {
    return <KeywordSkeleton />
  }

  return (
    <div className="grid grid-cols-2 gap-4">
      {Array.from({ length: 6 }).map((_, index) => (
        <BrandCardSkeleton key={index} />
      ))}
    </div>
  )
}
