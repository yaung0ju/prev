"use client"

import { useRef, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import ProductCard from "./product-card"
import { useSupabaseRecommendations } from "@/hooks/useSupabaseRecommendations"

interface Product {
  id: number
  name: string
  brand: string
  price: number
  originalPrice?: number
  image: string
  isLiked?: boolean
}

type TabType = "itemForYou" | "recentlyViewed" | "popular"

export default function RecommendationSections() {
  const { itemForYou, recentlyViewed, popular, loading, error } = useSupabaseRecommendations()
  const [activeTab, setActiveTab] = useState<TabType>("itemForYou")
  const scrollRef = useRef<HTMLDivElement>(null)

  const tabs = [
    { id: "itemForYou", label: "ITEM FOR YOU" },
    { id: "recentlyViewed", label: "최근 본 상품" },
    { id: "popular", label: "인기 상품" },
  ]

  const handleTabClick = (tabId: TabType) => {
    setActiveTab(tabId)
    // Scroll to the beginning of the slider when tab changes
    if (scrollRef.current) {
      scrollRef.current.scrollTo({ left: 0, behavior: "smooth" })
    }
  }

  const currentProducts: Product[] = (() => {
    switch (activeTab) {
      case "itemForYou":
        return itemForYou
      case "recentlyViewed":
        return recentlyViewed
      case "popular":
        return popular
      default:
        return []
    }
  })().slice(0, 30) // Limit to max 30 products

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="bg-gray-50 rounded-lg p-4 animate-pulse">
          <div className="h-6 bg-gray-200 rounded w-32 mb-4"></div>
          <div className="flex gap-4">
            {[1, 2, 3, 4].map((j) => (
              <div key={j} className="flex-none" style={{ width: `calc((100% - 48px) / 3.33)` }}>
                <div className="aspect-square bg-gray-200 rounded-lg mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-1"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-center">
        <p className="text-red-600">{error}</p>
        <button className="mt-2 text-sm text-red-500 hover:text-red-700" onClick={() => window.location.reload()}>
          다시 시도
        </button>
      </div>
    )
  }

  return (
    <section className="bg-gray-50 rounded-lg p-4 relative">
      {/* Tabs */}
      <div className="flex space-x-2 mb-4">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => handleTabClick(tab.id as TabType)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              activeTab === tab.id ? "bg-pink-500 text-white" : "bg-gray-200 text-gray-700 hover:bg-gray-300"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Slider Content */}
      <div className="relative overflow-hidden -mx-1">
        <div
          ref={scrollRef}
          className="flex gap-4 overflow-x-auto scrollbar-hide pb-2 px-1"
          style={{
            scrollbarWidth: "none",
            msOverflowStyle: "none",
            WebkitScrollbar: { display: "none" },
          }}
        >
          <AnimatePresence mode="wait">
            {currentProducts.map((product, index) => (
              <motion.div
                key={`${activeTab}-${product.id}`} // Key includes activeTab for re-animation on tab change
                className="flex-none"
                style={{
                  width: `calc((100% - 48px) / 3.33)`, // 3 + 1/3 items on mobile
                  minWidth: "90px", // Ensure minimum size for very small screens
                }}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
                whileHover={{
                  x: -8,
                  transition: { duration: 0.2 },
                }}
              >
                <ProductCard {...product} />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </section>
  )
}
