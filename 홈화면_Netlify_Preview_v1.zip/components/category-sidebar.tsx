"use client"

import { useState, useMemo, useEffect, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  X,
  Search,
  ChevronRight,
  TrendingUp,
  Clock,
  ShoppingBag,
  Gem,
  Watch,
  Shirt,
  Users,
  Baby,
  Home,
  MessageCircle,
  Lightbulb,
} from "lucide-react"

interface CategorySidebarProps {
  isOpen: boolean
  onClose: () => void
}

interface SubCategory {
  id: string
  name: string
  count?: number
  keywords?: string[]
}

interface MainCategory {
  id: string
  name: string
  icon: any
  subcategories: SubCategory[]
  keywords?: string[]
}

const categoryData: MainCategory[] = [
  {
    id: "BAG",
    name: "가방",
    icon: ShoppingBag,
    keywords: ["백", "파우치", "케이스"],
    subcategories: [
      { id: "tote", name: "토트백", count: 245, keywords: ["토트", "숄더백", "큰가방"] },
      { id: "crossbody", name: "크로스백/숄더백", count: 189, keywords: ["크로스", "숄더", "메신저백"] },
      { id: "hobo", name: "호보백/버킷백", count: 156, keywords: ["호보", "버킷", "둥근가방"] },
      { id: "mini", name: "미니백/백팩", count: 134, keywords: ["미니", "백팩", "작은가방", "배낭"] },
      { id: "clutch", name: "클러치/파우치", count: 98, keywords: ["클러치", "파우치", "손가방", "이브닝백"] },
      { id: "wallet", name: "지갑", count: 167, keywords: ["지갑", "월렛", "카드지갑", "장지갑"] },
    ],
  },
  {
    id: "JEWELRY",
    name: "주얼리",
    icon: Gem,
    keywords: ["쥬얼리", "액세서리", "장신구"],
    subcategories: [
      { id: "ring", name: "반지/귀걸이", count: 312, keywords: ["반지", "링", "귀걸이", "이어링"] },
      { id: "necklace", name: "팔찌/목걸이", count: 278, keywords: ["목걸이", "팔찌", "체인", "펜던트"] },
      { id: "brooch", name: "브로치", count: 45, keywords: ["브로치", "핀", "장식핀"] },
    ],
  },
  {
    id: "TIMEPIECE",
    name: "시계",
    icon: Watch,
    keywords: ["워치", "타임피스"],
    subcategories: [
      { id: "women-watch", name: "여성시계", count: 189, keywords: ["여성시계", "레이디스워치", "여자시계"] },
      { id: "men-watch", name: "남성시계", count: 156, keywords: ["남성시계", "맨즈워치", "남자시계"] },
    ],
  },
  {
    id: "WOMEN",
    name: "여성패션",
    icon: Shirt,
    keywords: ["여성복", "레이디스", "우먼"],
    subcategories: [
      { id: "hat-belt", name: "모자/벨트", count: 89, keywords: ["모자", "벨트", "햇", "허리띠"] },
      { id: "eyewear", name: "아이웨어", count: 67, keywords: ["선글라스", "안경", "아이웨어"] },
      { id: "scarf", name: "트윌리/머플러", count: 45, keywords: ["스카프", "트윌리", "머플러", "목도리"] },
      { id: "acc", name: "액세서리", count: 123, keywords: ["액세서리", "소품", "장신구"] },
      { id: "swimwear", name: "수영복", count: 34, keywords: ["수영복", "비키니", "원피스수영복"] },
    ],
  },
  {
    id: "MEN",
    name: "남성패션",
    icon: Users,
    keywords: ["남성복", "맨즈", "남자"],
    subcategories: [
      { id: "men-bag", name: "가방/지갑", count: 78, keywords: ["남성가방", "남자지갑", "서류가방"] },
      { id: "men-acc", name: "벨트/넥타이", count: 56, keywords: ["남성벨트", "넥타이", "타이"] },
    ],
  },
  {
    id: "HAUTE_PET",
    name: "오뜨펫",
    icon: Baby,
    keywords: ["펫", "반려동물", "애완동물"],
    subcategories: [
      { id: "pet-clothes", name: "펫의류", count: 45, keywords: ["펫옷", "강아지옷", "고양이옷"] },
      { id: "pet-goods", name: "펫용품", count: 67, keywords: ["펫용품", "반려동물용품", "펫액세서리"] },
    ],
  },
  {
    id: "KIDS_MOM",
    name: "키즈&맘",
    icon: Baby,
    keywords: ["키즈", "아이", "엄마", "맘"],
    subcategories: [
      { id: "kids-clothes", name: "의류", count: 89, keywords: ["키즈의류", "아동복", "아이옷"] },
      { id: "baby-goods", name: "육아용품", count: 123, keywords: ["육아용품", "베이비용품", "유아용품"] },
    ],
  },
  {
    id: "MAISON",
    name: "메종",
    icon: Home,
    keywords: ["홈", "리빙", "인테리어"],
    subcategories: [
      { id: "tableware", name: "테이블웨어", count: 67, keywords: ["식기", "그릇", "컵", "접시"] },
      { id: "living", name: "메종리빙", count: 89, keywords: ["홈데코", "인테리어", "리빙용품"] },
    ],
  },
  {
    id: "COMMUNITY",
    name: "커뮤니티",
    icon: MessageCircle,
    keywords: ["소통", "게시판"],
    subcategories: [
      { id: "process", name: "제작공정", count: 12, keywords: ["제작", "공정", "만들기"] },
      { id: "notice", name: "공지사항", count: 8, keywords: ["공지", "알림", "소식"] },
    ],
  },
]

// 한글 초성 추출 함수
const getInitialConsonants = (str: string): string => {
  const initials = [
    "ㄱ",
    "ㄲ",
    "ㄴ",
    "ㄷ",
    "ㄸ",
    "ㄹ",
    "ㅁ",
    "ㅂ",
    "ㅃ",
    "ㅅ",
    "ㅆ",
    "ㅇ",
    "ㅈ",
    "ㅉ",
    "ㅊ",
    "ㅋ",
    "ㅌ",
    "ㅍ",
    "ㅎ",
  ]

  return str
    .split("")
    .map((char) => {
      const code = char.charCodeAt(0) - 44032
      if (code >= 0 && code <= 11171) {
        return initials[Math.floor(code / 588)]
      }
      return char
    })
    .join("")
}

// 검색 매칭 함수
const matchesSearch = (text: string, keywords: string[] = [], searchQuery: string): boolean => {
  const query = searchQuery.toLowerCase().trim()
  if (!query) return true

  // 직접 매칭
  if (text.toLowerCase().includes(query)) return true

  // 키워드 매칭
  if (keywords.some((keyword) => keyword.toLowerCase().includes(query))) return true

  // 초성 매칭
  const textInitials = getInitialConsonants(text).toLowerCase()
  if (textInitials.includes(query)) return true

  return false
}

// 유사도 계산 함수 (Levenshtein distance 기반)
const calculateSimilarity = (str1: string, str2: string): number => {
  const matrix = Array(str2.length + 1)
    .fill(null)
    .map(() => Array(str1.length + 1).fill(null))

  for (let i = 0; i <= str1.length; i++) matrix[0][i] = i
  for (let j = 0; j <= str2.length; j++) matrix[j][0] = j

  for (let j = 1; j <= str2.length; j++) {
    for (let i = 1; i <= str1.length; i++) {
      const indicator = str1[i - 1] === str2[j - 1] ? 0 : 1
      matrix[j][i] = Math.min(matrix[j][i - 1] + 1, matrix[j - 1][i] + 1, matrix[j - 1][i - 1] + indicator)
    }
  }

  const maxLength = Math.max(str1.length, str2.length)
  return maxLength === 0 ? 1 : (maxLength - matrix[str2.length][str1.length]) / maxLength
}

type SortType = "popular" | "newest"

interface SearchResult {
  type: "main" | "sub"
  mainCategory: MainCategory
  subCategory?: SubCategory
  matchScore: number
}

export default function CategorySidebar({ isOpen, onClose }: CategorySidebarProps) {
  const [selectedMainCategory, setSelectedMainCategory] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [sortType, setSortType] = useState<SortType>("popular")
  const [breadcrumb, setBreadcrumb] = useState<string[]>([])
  const sidebarRef = useRef<HTMLDivElement>(null)

  // Close sidebar when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (sidebarRef.current && !sidebarRef.current.contains(event.target as Node)) {
        onClose()
      }
    }

    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside)
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [isOpen, onClose])

  // 검색 결과 계산
  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) return null

    const results: SearchResult[] = []
    const query = searchQuery.toLowerCase().trim()

    // 1. 하위 카테고리 우선 검색
    categoryData.forEach((mainCat) => {
      mainCat.subcategories.forEach((subCat) => {
        if (matchesSearch(subCat.name, subCat.keywords, query)) {
          const matchScore = calculateSimilarity(query, subCat.name.toLowerCase())
          results.push({
            type: "sub",
            mainCategory: mainCat,
            subCategory: subCat,
            matchScore,
          })
        }
      })
    })

    // 2. 상위 카테고리 검색 (하위 매칭이 없을 때)
    if (results.length === 0) {
      categoryData.forEach((mainCat) => {
        if (matchesSearch(mainCat.name, mainCat.keywords, query)) {
          const matchScore = calculateSimilarity(query, mainCat.name.toLowerCase())
          results.push({
            type: "main",
            mainCategory: mainCat,
            matchScore,
          })
        }
      })
    }

    // 매칭 점수로 정렬
    return results.sort((a, b) => b.matchScore - a.matchScore)
  }, [searchQuery])

  // 유사 카테고리 제안
  const suggestedCategories = useMemo(() => {
    if (!searchQuery.trim() || (searchResults && searchResults.length > 0)) return []

    const suggestions: {
      category: MainCategory | SubCategory
      type: "main" | "sub"
      similarity: number
      mainCat?: MainCategory
    }[] = []
    const query = searchQuery.toLowerCase().trim()

    // 모든 카테고리에서 유사도 계산
    categoryData.forEach((mainCat) => {
      const mainSimilarity = calculateSimilarity(query, mainCat.name.toLowerCase())
      if (mainSimilarity > 0.3) {
        suggestions.push({ category: mainCat, type: "main", similarity: mainSimilarity })
      }

      mainCat.subcategories.forEach((subCat) => {
        const subSimilarity = calculateSimilarity(query, subCat.name.toLowerCase())
        if (subSimilarity > 0.3) {
          suggestions.push({ category: subCat, type: "sub", similarity: subSimilarity, mainCat })
        }
      })
    })

    return suggestions.sort((a, b) => b.similarity - a.similarity).slice(0, 4)
  }, [searchQuery, searchResults])

  const handleMainCategoryClick = (categoryId: string, categoryName: string) => {
    setSelectedMainCategory(categoryId)
    setBreadcrumb([categoryName])
  }

  const handleSubcategoryClick = (subcategory: SubCategory) => {
    const mainCategory = categoryData.find((cat) => cat.id === selectedMainCategory)
    if (mainCategory) {
      setBreadcrumb([mainCategory.name, subcategory.name])
    }
    console.log(`Navigate to ${subcategory.name}`)
    onClose()
  }

  const handleSearchResultClick = (result: SearchResult) => {
    if (result.type === "sub" && result.subCategory) {
      setBreadcrumb([result.mainCategory.name, result.subCategory.name])
      console.log(`Navigate to ${result.subCategory.name}`)
    } else {
      setBreadcrumb([result.mainCategory.name])
      console.log(`Navigate to ${result.mainCategory.name}`)
    }
    onClose()
  }

  const handleSuggestionClick = (suggestion: {
    category: MainCategory | SubCategory
    type: "main" | "sub"
    mainCat?: MainCategory
  }) => {
    if (suggestion.type === "sub" && suggestion.mainCat) {
      setBreadcrumb([suggestion.mainCat.name, suggestion.category.name])
      console.log(`Navigate to ${suggestion.category.name}`)
    } else {
      setBreadcrumb([suggestion.category.name])
      console.log(`Navigate to ${suggestion.category.name}`)
    }
    onClose()
  }

  const handleBackToMain = () => {
    setSelectedMainCategory(null)
    setBreadcrumb([])
  }

  const handleSortChange = (newSortType: SortType) => {
    setSortType(newSortType)
  }

  const clearSearch = () => {
    setSearchQuery("")
  }

  const filteredCategories = searchQuery.trim()
    ? []
    : categoryData.filter(
        (category) =>
          category.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          category.subcategories.some((sub) => sub.name.toLowerCase().includes(searchQuery.toLowerCase())),
      )

  const selectedCategory = categoryData.find((cat) => cat.id === selectedMainCategory)
  const sortedSubcategories = selectedCategory?.subcategories.slice().sort((a, b) => {
    if (sortType === "popular") {
      return (b.count || 0) - (a.count || 0)
    } else {
      return a.name.localeCompare(b.name)
    }
  })

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            className="fixed inset-0 bg-black bg-opacity-50 z-50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          {/* Sidebar */}
          <motion.div
            ref={sidebarRef}
            className="fixed left-0 top-0 h-full w-full max-w-sm bg-white z-50 shadow-xl flex flex-col"
            initial={{ x: -400 }}
            animate={{ x: 0 }}
            exit={{ x: -400 }}
            transition={{ type: "tween", duration: 0.3 }}
          >
            {/* Header */}
            <div className="flex-shrink-0 p-4 border-b border-gray-200">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-bold">카테고리</h2>
                <button
                  onClick={onClose}
                  className="p-2 hover:bg-gray-100 rounded-xl transition-all duration-300 opacity-30 hover:opacity-100 shadow-sm"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Search Input */}
              <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="카테고리 검색 (초성 검색 가능)"
                  className="w-full pl-10 pr-10 py-2 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent shadow-sm"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                {searchQuery && (
                  <button
                    onClick={clearSearch}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1 hover:bg-gray-100 rounded-xl transition-all duration-300 opacity-30 hover:opacity-100"
                  >
                    <X className="w-3 h-3 text-gray-400" />
                  </button>
                )}
              </div>

              {/* Filter Buttons - Only show when not searching */}
              {!searchQuery.trim() && (
                <div className="flex space-x-2">
                  <button
                    onClick={() => handleSortChange("popular")}
                    className={`flex items-center space-x-1 px-3 py-2 rounded-xl text-sm transition-all duration-300 shadow-sm ${
                      sortType === "popular"
                        ? "bg-pink-100 text-pink-600 opacity-100"
                        : "bg-gray-100 text-gray-600 hover:bg-gray-200 opacity-30 hover:opacity-100"
                    }`}
                  >
                    <TrendingUp className="w-4 h-4" />
                    <span>인기순</span>
                  </button>
                  <button
                    onClick={() => handleSortChange("newest")}
                    className={`flex items-center space-x-1 px-3 py-2 rounded-xl text-sm transition-all duration-300 shadow-sm ${
                      sortType === "newest"
                        ? "bg-pink-100 text-pink-600 opacity-100"
                        : "bg-gray-100 text-gray-600 hover:bg-gray-200 opacity-30 hover:opacity-100"
                    }`}
                  >
                    <Clock className="w-4 h-4" />
                    <span>신상품순</span>
                  </button>
                </div>
              )}

              {/* Breadcrumb */}
              {breadcrumb.length > 0 && (
                <div className="flex items-center space-x-2 mt-4 text-sm text-gray-600">
                  <button
                    onClick={handleBackToMain}
                    className="hover:text-pink-500 transition-colors opacity-30 hover:opacity-100"
                  >
                    카테고리
                  </button>
                  {breadcrumb.map((crumb, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <ChevronRight className="w-3 h-3" />
                      <span className={index === breadcrumb.length - 1 ? "text-pink-500 font-medium" : ""}>
                        {crumb}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Content */}
            <div className="flex-1 overflow-hidden relative">
              {/* Search Results */}
              {searchQuery.trim() && (
                <div className="absolute inset-0 overflow-y-auto">
                  <div className="p-4">
                    {searchResults && searchResults.length > 0 ? (
                      <>
                        <h3 className="font-medium text-gray-900 mb-4">검색 결과 ({searchResults.length}개)</h3>
                        <div className="space-y-2">
                          {searchResults.map((result, index) => (
                            <motion.button
                              key={`${result.mainCategory.id}-${result.subCategory?.id || "main"}`}
                              className="w-full p-4 bg-white border border-gray-200 rounded-xl hover:border-pink-300 hover:bg-pink-50 transition-all duration-300 text-left shadow-sm opacity-30 hover:opacity-100"
                              initial={{ opacity: 0, y: 20 }}
                              animate={{ opacity: 0.3, y: 0 }}
                              whileHover={{ opacity: 1 }}
                              transition={{ duration: 0.3, delay: index * 0.05 }}
                              onClick={() => handleSearchResultClick(result)}
                            >
                              <div className="flex items-center justify-between">
                                <div className="flex items-center space-x-3">
                                  <div className="w-10 h-10 bg-pink-100 rounded-xl flex items-center justify-center">
                                    {result.mainCategory.icon && (
                                      <result.mainCategory.icon className="w-5 h-5 text-pink-600" />
                                    )}
                                  </div>
                                  <div>
                                    {result.type === "sub" && result.subCategory ? (
                                      <>
                                        <p className="font-medium text-gray-900">{result.subCategory.name}</p>
                                        <p className="text-sm text-gray-500">
                                          {result.mainCategory.name} &gt; {result.subCategory.count}개 상품
                                        </p>
                                      </>
                                    ) : (
                                      <>
                                        <p className="font-medium text-gray-900">{result.mainCategory.name}</p>
                                        <p className="text-sm text-gray-500">
                                          {result.mainCategory.subcategories.length}개 하위카테고리
                                        </p>
                                      </>
                                    )}
                                  </div>
                                </div>
                                <ChevronRight className="w-4 h-4 text-gray-400" />
                              </div>
                            </motion.button>
                          ))}
                        </div>
                      </>
                    ) : (
                      <div className="text-center py-8">
                        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                          <Search className="w-8 h-8 text-gray-400" />
                        </div>
                        <p className="text-gray-500 mb-4">'{searchQuery}'에 대한 검색 결과가 없습니다.</p>

                        {/* 유사 카테고리 제안 */}
                        {suggestedCategories.length > 0 && (
                          <div className="mt-6">
                            <div className="flex items-center justify-center space-x-2 mb-4">
                              <Lightbulb className="w-4 h-4 text-yellow-500" />
                              <p className="text-sm font-medium text-gray-700">이런 카테고리는 어떠세요?</p>
                            </div>
                            <div className="space-y-2">
                              {suggestedCategories.map((suggestion, index) => (
                                <motion.button
                                  key={`suggestion-${index}`}
                                  className="w-full p-3 bg-yellow-50 border border-yellow-200 rounded-xl hover:bg-yellow-100 transition-all duration-300 text-left shadow-sm opacity-30 hover:opacity-100"
                                  initial={{ opacity: 0, scale: 0.9 }}
                                  animate={{ opacity: 0.3, scale: 1 }}
                                  whileHover={{ opacity: 1 }}
                                  transition={{ duration: 0.2, delay: index * 0.1 }}
                                  onClick={() => handleSuggestionClick(suggestion)}
                                >
                                  <div className="flex items-center space-x-3">
                                    <div className="w-8 h-8 bg-yellow-200 rounded-xl flex items-center justify-center">
                                      {suggestion.type === "main" && suggestion.category.icon && (
                                        <suggestion.category.icon className="w-4 h-4 text-yellow-700" />
                                      )}
                                      {suggestion.type === "sub" && suggestion.mainCat && suggestion.mainCat.icon && (
                                        <suggestion.mainCat.icon className="w-4 h-4 text-yellow-700" />
                                      )}
                                    </div>
                                    <div>
                                      <p className="text-sm font-medium text-gray-900">{suggestion.category.name}</p>
                                      {suggestion.type === "sub" && suggestion.mainCat && (
                                        <p className="text-xs text-gray-500">{suggestion.mainCat.name} 카테고리</p>
                                      )}
                                    </div>
                                  </div>
                                </motion.button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Main Categories */}
              <AnimatePresence mode="wait">
                {!selectedMainCategory && !searchQuery.trim() && (
                  <motion.div
                    key="main-categories"
                    className="absolute inset-0 overflow-y-auto"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="p-4 space-y-2">
                      {filteredCategories.map((category, index) => {
                        const Icon = category.icon
                        const totalCount = category.subcategories.reduce((sum, sub) => sum + (sub.count || 0), 0)

                        return (
                          <motion.button
                            key={category.id}
                            className="w-full p-4 bg-white border border-gray-200 rounded-xl hover:border-pink-300 hover:bg-pink-50 transition-all duration-300 text-left group shadow-sm opacity-30 hover:opacity-100"
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 0.3, y: 0 }}
                            whileHover={{ opacity: 1 }}
                            transition={{ duration: 0.3, delay: index * 0.05 }}
                            onClick={() => handleMainCategoryClick(category.id, category.name)}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-3">
                                <div className="w-10 h-10 bg-pink-100 rounded-xl flex items-center justify-center group-hover:bg-pink-200 transition-colors">
                                  {Icon && <Icon className="w-5 h-5 text-pink-600" />}
                                </div>
                                <div>
                                  <p className="font-medium text-gray-900 group-hover:text-pink-600 transition-colors">
                                    {category.name}
                                  </p>
                                  <p className="text-sm text-gray-500">
                                    {category.subcategories.length}개 하위카테고리 • {totalCount}개 상품
                                  </p>
                                </div>
                              </div>
                              <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-pink-500 transition-colors" />
                            </div>
                          </motion.button>
                        )
                      })}
                    </div>
                  </motion.div>
                )}

                {/* Subcategories */}
                {selectedMainCategory && selectedCategory && !searchQuery.trim() && (
                  <motion.div
                    key="subcategories"
                    className="absolute inset-0 overflow-y-auto"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="p-4">
                      {/* Back Button */}
                      <button
                        onClick={handleBackToMain}
                        className="flex items-center space-x-2 p-2 hover:bg-gray-100 rounded-xl transition-all duration-300 mb-4 text-gray-600 hover:text-pink-500 opacity-30 hover:opacity-100"
                      >
                        <ChevronRight className="w-4 h-4 rotate-180" />
                        <span className="text-sm">뒤로가기</span>
                      </button>

                      {/* Category Header */}
                      <div className="flex items-center space-x-3 mb-6 p-4 bg-pink-50 rounded-xl">
                        <div className="w-12 h-12 bg-pink-100 rounded-xl flex items-center justify-center">
                          {selectedCategory.icon && <selectedCategory.icon className="w-6 h-6 text-pink-600" />}
                        </div>
                        <div>
                          <h3 className="font-bold text-gray-900">{selectedCategory.name}</h3>
                          <p className="text-sm text-gray-600">
                            {selectedCategory.subcategories.length}개 하위카테고리
                          </p>
                        </div>
                      </div>

                      {/* Subcategory List */}
                      <div className="space-y-2">
                        {sortedSubcategories?.map((subcategory, index) => (
                          <motion.button
                            key={subcategory.id}
                            className="w-full p-4 bg-white border border-gray-200 rounded-xl hover:border-pink-300 hover:bg-pink-50 transition-all duration-300 text-left shadow-sm opacity-30 hover:opacity-100"
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 0.3, y: 0 }}
                            whileHover={{ opacity: 1 }}
                            transition={{ duration: 0.3, delay: index * 0.05 }}
                            onClick={() => handleSubcategoryClick(subcategory)}
                          >
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="font-medium text-gray-900 hover:text-pink-600 transition-colors">
                                  {subcategory.name}
                                </p>
                                {subcategory.count && (
                                  <p className="text-sm text-gray-500 mt-1">{subcategory.count}개 상품</p>
                                )}
                              </div>
                              <ChevronRight className="w-4 h-4 text-gray-400" />
                            </div>
                          </motion.button>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}
