"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Search, X, Clock, TrendingUp } from "lucide-react"
import { useRouter } from "next/navigation"
import { useDebounce } from "@/hooks/useDebounce"

interface SearchOverlayProps {
  isOpen: boolean
  onClose: () => void
}

const recommendedKeywords = [
  "샤넬 가방",
  "루이비통 지갑",
  "에르메스 버킨백",
  "구찌 스니커즈",
  "프라다 백팩",
  "디올 향수",
  "까르띠에 시계",
  "티파니 반지",
  "발렌시아가 신발",
  "생로랑 가방",
]

const trendingKeywords = [
  "신상품",
  "한정판",
  "세일",
  "럭셔리 가방",
  "디자이너 시계",
  "브랜드 지갑",
  "명품 신발",
  "주얼리",
]

const recentSearches = ["샤넬 클래식", "루이비통 네버풀", "에르메스 켈리백"]

export default function SearchOverlay({ isOpen, onClose }: SearchOverlayProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)
  const router = useRouter()

  const debouncedSearchQuery = useDebounce(searchQuery, 300)

  // Mock search function
  useEffect(() => {
    const performSearch = async () => {
      if (debouncedSearchQuery.trim() === "") {
        setSearchResults([])
        setIsLoading(false)
        return
      }

      setIsLoading(true)

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 200))

      // Mock search results
      const mockResults = recommendedKeywords.filter((keyword) =>
        keyword.toLowerCase().includes(debouncedSearchQuery.toLowerCase()),
      )

      setSearchResults(mockResults)
      setIsLoading(false)
    }

    performSearch()
  }, [debouncedSearchQuery])

  // Focus input when overlay opens
  useEffect(() => {
    if (isOpen && inputRef.current) {
      setTimeout(() => {
        inputRef.current?.focus()
      }, 100)
    }
  }, [isOpen])

  // Prevent body scroll when overlay is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = "unset"
    }

    return () => {
      document.body.style.overflow = "unset"
    }
  }, [isOpen])

  // Reset search when overlay closes
  useEffect(() => {
    if (!isOpen) {
      setSearchQuery("")
      setSearchResults([])
    }
  }, [isOpen])

  const handleSearch = (query: string) => {
    if (query.trim()) {
      router.push(`/search?q=${encodeURIComponent(query)}`)
      onClose()
    }
  }

  const handleKeywordClick = (keyword: string) => {
    handleSearch(keyword)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    handleSearch(searchQuery)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value)
  }

  const clearSearch = () => {
    setSearchQuery("")
    setSearchResults([])
    inputRef.current?.focus()
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 bg-white z-50 flex flex-col"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
        >
          {/* Header */}
          <div className="flex-shrink-0 p-4 border-b border-gray-200">
            <div className="flex items-center space-x-4">
              <form onSubmit={handleSubmit} className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  ref={inputRef}
                  type="text"
                  placeholder="브랜드/상품명/카테고리 검색"
                  className="w-full pl-12 pr-12 py-3 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent text-base"
                  value={searchQuery}
                  onChange={handleInputChange}
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={clearSearch}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1 hover:bg-gray-100 rounded-full"
                  >
                    <X className="w-4 h-4 text-gray-400" />
                  </button>
                )}
              </form>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                aria-label="닫기"
              >
                <X className="w-6 h-6 text-gray-600" />
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto" style={{ WebkitOverflowScrolling: "touch" }}>
            <div className="p-4 space-y-6">
              {/* Search Results */}
              {searchQuery && (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-medium text-gray-900">검색 결과</h3>
                    {isLoading && (
                      <div className="w-4 h-4 border-2 border-pink-300 border-t-pink-500 rounded-full animate-spin"></div>
                    )}
                  </div>

                  {searchResults.length > 0 ? (
                    <div className="space-y-2">
                      {searchResults.map((result, index) => (
                        <motion.button
                          key={result}
                          className="w-full p-3 text-left hover:bg-gray-50 rounded-lg transition-colors"
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.2, delay: index * 0.05 }}
                          onClick={() => handleKeywordClick(result)}
                        >
                          <div className="flex items-center space-x-3">
                            <Search className="w-4 h-4 text-gray-400" />
                            <span className="text-gray-900">{result}</span>
                          </div>
                        </motion.button>
                      ))}
                    </div>
                  ) : (
                    !isLoading && (
                      <div className="text-center py-8 text-gray-500">
                        <p>검색 결과가 없습니다.</p>
                      </div>
                    )
                  )}
                </div>
              )}

              {/* Recent Searches */}
              {!searchQuery && recentSearches.length > 0 && (
                <div>
                  <div className="flex items-center space-x-2 mb-4">
                    <Clock className="w-4 h-4 text-gray-500" />
                    <h3 className="font-medium text-gray-900">최근 검색어</h3>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {recentSearches.map((search, index) => (
                      <motion.button
                        key={search}
                        className="px-3 py-2 bg-gray-100 hover:bg-pink-100 hover:text-pink-600 rounded-full text-sm transition-colors"
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.2, delay: index * 0.05 }}
                        onClick={() => handleKeywordClick(search)}
                      >
                        {search}
                      </motion.button>
                    ))}
                  </div>
                </div>
              )}

              {/* Trending Keywords */}
              {!searchQuery && (
                <div>
                  <div className="flex items-center space-x-2 mb-4">
                    <TrendingUp className="w-4 h-4 text-pink-500" />
                    <h3 className="font-medium text-gray-900">인기 검색어</h3>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {trendingKeywords.map((keyword, index) => (
                      <motion.button
                        key={keyword}
                        className="px-3 py-2 bg-pink-50 hover:bg-pink-100 text-pink-600 rounded-full text-sm transition-colors"
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.2, delay: index * 0.05 }}
                        onClick={() => handleKeywordClick(keyword)}
                      >
                        {keyword}
                      </motion.button>
                    ))}
                  </div>
                </div>
              )}

              {/* Recommended Keywords */}
              {!searchQuery && (
                <div>
                  <h3 className="font-medium text-gray-900 mb-4">추천 검색어</h3>
                  <div className="space-y-2">
                    {recommendedKeywords.slice(0, 8).map((keyword, index) => (
                      <motion.button
                        key={keyword}
                        className="w-full p-3 text-left hover:bg-gray-50 rounded-lg transition-colors"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.2, delay: index * 0.05 }}
                        onClick={() => handleKeywordClick(keyword)}
                      >
                        <div className="flex items-center space-x-3">
                          <Search className="w-4 h-4 text-gray-400" />
                          <span className="text-gray-900">{keyword}</span>
                        </div>
                      </motion.button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
