"use client"

import type React from "react"

import { motion, AnimatePresence } from "framer-motion"
import { Heart, ChevronLeft, ChevronRight } from "lucide-react"
import Image from "next/image"
import { useState } from "react"
import { useRecentProducts } from "@/hooks/useRecentProducts"

interface ProductCardProps {
  id: number
  name: string
  brand: string
  price: number
  originalPrice?: number
  images?: string[]
  image?: string
  isLiked?: boolean
  showImageNavigation?: boolean
}

export default function ProductCard({
  id,
  name,
  brand,
  price,
  originalPrice,
  images,
  image,
  isLiked = false,
  showImageNavigation = true,
}: ProductCardProps) {
  const [liked, setLiked] = useState(isLiked)
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [isHovered, setIsHovered] = useState(false)
  const { addRecentProduct } = useRecentProducts()

  // Safe image handling - filter out null/undefined/empty values
  const productImages = (images || (image ? [image] : []))
    .filter((img) => img && img.trim() !== "")
    .map((img) => img || "/placeholder.svg?height=300&width=300")

  // Fallback if no valid images
  if (productImages.length === 0) {
    productImages.push("/placeholder.svg?height=300&width=300")
  }

  const handleLikeClick = (e: React.MouseEvent) => {
    e.stopPropagation()
    setLiked(!liked)
  }

  const handleCardClick = () => {
    // Add to recent products when card is clicked
    addRecentProduct({
      id,
      name,
      brand,
      price,
      originalPrice,
      image: productImages[0], // Use first image as thumbnail
    })

    console.log(`Navigate to product ${id}`)
    // Here you would typically navigate to the product detail page
    // router.push(`/product/${id}`)
  }

  const nextImage = (e: React.MouseEvent) => {
    e.stopPropagation()
    setCurrentImageIndex((prev) => (prev + 1) % productImages.length)
  }

  const prevImage = (e: React.MouseEvent) => {
    e.stopPropagation()
    setCurrentImageIndex((prev) => (prev - 1 + productImages.length) % productImages.length)
  }

  return (
    <motion.div
      className="bg-white rounded-xl overflow-hidden cursor-pointer group shadow-sm hover:shadow-lg transition-all duration-300"
      whileHover={{ y: -2 }}
      transition={{ duration: 0.2 }}
      onClick={handleCardClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative aspect-square overflow-hidden bg-gray-100">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentImageIndex}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
            className="w-full h-full"
          >
            <Image
              src={productImages[currentImageIndex] || "/placeholder.svg"}
              alt={name}
              fill
              className="object-cover group-hover:scale-105 transition-transform duration-500"
              loading="lazy"
            />
          </motion.div>
        </AnimatePresence>

        {/* Image Navigation */}
        {showImageNavigation && productImages.length > 1 && (
          <>
            <motion.button
              onClick={prevImage}
              className="absolute left-2 top-1/2 -translate-y-1/2 p-1 transition-all duration-300 opacity-30 hover:opacity-100"
              whileHover={{ scale: 1.1, opacity: 1 }}
              whileTap={{ scale: 0.9, opacity: 1 }}
              initial={{ opacity: 0.3 }}
              animate={{ opacity: isHovered ? 1 : 0.3 }}
            >
              <ChevronLeft className="w-4 h-4 text-white drop-shadow-lg" />
            </motion.button>
            <motion.button
              onClick={nextImage}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-1 transition-all duration-300 opacity-30 hover:opacity-100"
              whileHover={{ scale: 1.1, opacity: 1 }}
              whileTap={{ scale: 0.9, opacity: 1 }}
              initial={{ opacity: 0.3 }}
              animate={{ opacity: isHovered ? 1 : 0.3 }}
            >
              <ChevronRight className="w-4 h-4 text-white drop-shadow-lg" />
            </motion.button>

            {/* Image dots indicator */}
            <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex space-x-1">
              {productImages.map((_, index) => (
                <div
                  key={index}
                  className={`w-1.5 h-1.5 rounded-full transition-all ${
                    index === currentImageIndex ? "bg-white" : "bg-white bg-opacity-50"
                  }`}
                />
              ))}
            </div>
          </>
        )}

        {/* Heart Button - Always visible as hollow, filled on hover/like */}
        <div className="absolute top-2 right-2">
          <motion.button
            onClick={handleLikeClick}
            className="p-2 transition-all duration-300"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            aria-label={liked ? "좋아요 취소" : "좋아요"}
          >
            <Heart
              className={`w-4 h-4 transition-all duration-300 ${
                liked
                  ? "fill-pink-500 text-pink-500"
                  : "text-white stroke-2 drop-shadow-lg hover:fill-pink-500 hover:text-pink-500"
              }`}
            />
          </motion.button>
        </div>
      </div>

      <div className="p-4">
        <p className="text-xs text-gray-500 mb-1">{brand}</p>
        <h3 className="text-sm font-medium text-gray-900 mb-2 line-clamp-2">{name}</h3>
        <div className="flex items-center space-x-2">
          <span className="text-lg font-bold text-gray-900">₩{price.toLocaleString()}</span>
          {originalPrice && price < originalPrice && (
            <span className="text-sm font-bold text-red-500 ml-2">
              {Math.round(((originalPrice - price) / originalPrice) * 100)}%
            </span>
          )}
          {originalPrice && (
            <span className="text-sm text-gray-500 line-through">₩{originalPrice.toLocaleString()}</span>
          )}
        </div>
      </div>
    </motion.div>
  )
}
